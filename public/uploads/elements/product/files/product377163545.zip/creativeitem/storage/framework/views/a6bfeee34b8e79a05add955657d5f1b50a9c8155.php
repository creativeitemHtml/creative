<div class="bg-white box-shadow-6 pt-26 px-26 pb-30 bd-r-5">
	<!-- Title -->
	<div class="d-flex justify-content-end align-items-center flex-wrap g-10 pb-30">
	  <a href="javascript:;" class="btn-main new-project-btn" onclick="showAjaxModal('<?php echo e(route('admin.create_product')); ?>', '<?php echo e(get_phrase("Create new product")); ?>')"><?php echo e(get_phrase('Create product')); ?></a>
	</div>
	
	<div class="row">
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php
			if($product->slug == 'academy-lms') {
				$card_color = 'doc-item-academy-LMS';
				$product_img = 'academy-lms.svg';
			} else if($product->slug == 'ekattor-7') {
				$card_color = 'doc-item-ekattor';
				$product_img = 'ekattor-lms.svg';
			} else if($product->slug == 'learny-lms') {
				$card_color = 'doc-item-learny-LMS';
				$product_img = 'learny-lms.svg';
			} else if($product->slug == 'mastery-lms') {
				$card_color = 'doc-item-mastery-LMS';
				$product_img = 'mastery-lms.svg';
			} else if($product->slug == 'checkout') {
				$card_color = 'doc-item-checkout';
				$product_img = 'checkout.svg';
			} else if($product->slug == 'atlas') {
				$card_color = 'doc-item-atlas';
				$product_img = 'atlas.svg';
			} else if($product->slug == 'ekattor-8') {
				$card_color = 'doc-item-ekattor8';
				$product_img = 'ekattor8.svg';
			} else if($product->slug == 'sociopro') {
				$card_color = 'doc-item-academy-LMS';
				$product_img = 'academy-lms.svg';
			} else if($product->slug == 'ekushe-crm') {
				$card_color = 'doc-item-mastery-LMS';
				$product_img = 'academy-lms.svg';
			} else {
				$card_color = 'doc-item-mastery-LMS';
				$product_img = 'academy-lms.svg';
			}
			?>
			<div class="col-lg-4 col-md-4 col-sm-6">
				<div class="doc-item <?php echo e($card_color); ?> d-flex justify-content-between">
					<div class="doc-item-icon">
						<img src="<?php echo e(asset('assets/img/doc-icon/'.$product_img)); ?>" alt="" />
					</div>
					<div class="content">
						<div class="doc-item-name"><?php echo e($product->name); ?></div>
						<p class="doc-item-article">15 Article</p>
					</div>
					<!-- Dropdown -->
					<div class="payfile-option pb-4">
						<button
						type="button"
						class="dropdown-toggle"
						data-bs-toggle="dropdown"
						aria-expanded="false"
						>
						<i class="fa-solid fa-ellipsis-vertical"></i>
						</button>
						<ul class="dropdown-menu dropdown-menu-end">
						<li>
							<a class="dropdown-item" href="javascript:;" onclick="showAjaxModal('<?php echo e(route('admin.edit_product', ['id' => $product->id])); ?>', '<?php echo e(get_phrase("Update product")); ?>')"><?php echo e(get_phrase('Edit')); ?></a>
						</li>
						<li>
							<a class="dropdown-item" href="javascript:;" onclick="confirmModal('<?php echo e(route('admin.product.delete', ['id' => $product->id])); ?>', 'undefined')"><?php echo e(get_phrase('Delete')); ?></a>
						</li>
						</ul>
					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<!-- Pagination -->
	<div class="adminPanel-pagi pt-30">
		<?php echo e($products->links('pagination::bootstrap-4')); ?>

	</div>
	
</div><?php /**PATH C:\xampp\htdocs\creativeitem\resources\views/backend/admin/products.blade.php ENDPATH**/ ?>