<!-- Start Main Header -->
<header id="main-header" class="main-header">
  <div class="menu-header">
    <div class="container container-elements">
      <div class="main-menu">
        <div class="row justify-content-between align-items-center">
          <div class="col-lg-2 col-md-4 col-sm-4 col-3 logo-col">
            <div class="logo">
              <a href="index.html" class="desk-logo">
                <img src="<?php echo e(asset('assets/img/logo-white.png')); ?>" alt="logo" />
              </a>
              <a href="index.html" class="mobile-logo">
                <img src="<?php echo e(asset('assets/img/logo-icon.png')); ?>" alt="logo" />
              </a>
            </div>
          </div>
          <div class="col-lg-7 col-md-4 col-sm-4 col-2 menu-col">
            <!--Main Menu-->
            <div class="main-menu-navigation">
              <nav class="navigation-main-area ul-li">
                <ul>
                  <li class="dropdown mega-menu-wrap">
                    <a href="#" class="active">Products</a>
                    <ul class="dropdown-menu clearfix mega-menu">
                      <div class="row">
                        <div class="col-lg-4">
                          <div class="mega-menu-items mega-border">
                            <a href="#" class="mega-menu-item">
                              <div class="icon">
                                <img
                                  src="<?php echo e(asset('assets/img/icon/elearning.svg')); ?>"
                                  alt=""
                                />
                              </div>
                              <div class="content">
                                <h3 class="title">LMS</h3>
                                <p class="info">
                                  34 WordPress Theme Collections and Great
                                  Features
                                </p>
                              </div>
                            </a>
                            <a href="#" class="mega-menu-item">
                              <div class="icon">
                                <img
                                  src="<?php echo e(asset('assets/img/icon/elearning.svg')); ?>"
                                  alt=""
                                />
                              </div>
                              <div class="content">
                                <h3 class="title">LMS</h3>
                                <p class="info">
                                  34 WordPress Theme Collections and Great
                                  Features
                                </p>
                              </div>
                            </a>
                          </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="mega-menu-items">
                            <a href="#" class="mega-menu-item">
                              <div class="icon">
                                <img
                                  src="<?php echo e(asset('assets/img/icon/elements.svg')); ?>"
                                  alt=""
                                />
                              </div>
                              <div class="content">
                                <h3 class="title">
                                  Elements <span>New</span>
                                </h3>
                                <p class="info">
                                  34 WordPress Theme Collections and Great
                                  Features
                                </p>
                              </div>
                            </a>
                            <a href="#" class="mega-menu-item">
                              <div class="icon">
                                <img
                                  src="<?php echo e(asset('assets/img/icon/elearning.svg')); ?>"
                                  alt=""
                                />
                              </div>
                              <div class="content">
                                <h3 class="title">LMS</h3>
                                <p class="info">
                                  34 WordPress Theme Collections and Great
                                  Features
                                </p>
                              </div>
                            </a>
                          </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="mega-menu-items">
                            <a href="#" class="mega-menu-item">
                              <div class="icon">
                                <img
                                  src="<?php echo e(asset('assets/img/icon/envato.svg')); ?>"
                                  alt=""
                                />
                              </div>
                              <div class="content">
                                <h3 class="title">Codecanyon</h3>
                                <p class="info">
                                  34 WordPress Theme Collections and Great
                                  Features
                                </p>
                              </div>
                            </a>
                            <a href="#" class="mega-menu-item">
                              <div class="icon">
                                <img
                                  src="<?php echo e(asset('assets/img/icon/clock.svg')); ?>"
                                  alt=""
                                />
                              </div>
                              <div class="content">
                                <h3 class="title">Coming Soon</h3>
                                <p class="info">
                                  34 WordPress Theme Collections and Great
                                  Features
                                </p>
                              </div>
                            </a>
                          </div>
                        </div>
                      </div>
                    </ul>
                  </li>
                  <li class="dropdown">
                    <a href="#">Service</a>
                  </li>
                  <li class="dropdown">
                    <a href="#">Blog</a>
                  </li>
                  <li class="dropdown">
                    <a href="#">Support </a>
                    <ul class="dropdown-menu clearfix">
                      <span></span>
                      <li><a href="signup.html">Sign Up</a></li>
                      <li><a href="login.html">Log In</a></li>
                      <li><a href="admin.html">Admin</a></li>
                      <li><a href="elements.html">Elements</a></li>
                      <li><a href="downloads.html">Downloads</a></li>
                      <li><a href="free-item.html">Free Item</a></li>
                      <li><a href="hire-us.html">Hire Us</a></li>
                      <li><a href="index.html">Home</a></li>
                      <li><a href="demo.html">Demo</a></li>
                    </ul>
                  </li>
                </ul>
              </nav>
            </div>
            <!-- Start Mobile Menu -->
            <div class="mobile_menu position-relative">
              <div class="mobile_menu_button open_mobile_menu">
                <img src="<?php echo e(asset('assets/img/icon/gl-mobile-menu.svg')); ?>" alt="" />
              </div>
              <div class="mobile_menu_wrap">
                <div class="mobile_menu_overlay open_mobile_menu"></div>
                <div class="mobile_menu_content">
                  <div
                    class="d-flex justify-content-between align-items-center px-20 py-11 bd-b-2"
                  >
                    <div class="m-brand-logo">
                      <a href="index.html"
                        ><img src="<?php echo e(asset('assets/img/logo-icon.png')); ?>" alt=""
                      /></a>
                    </div>
                    <div class="mobile_menu_close open_mobile_menu">
                      <i class="fa-solid fa-xmark"></i>
                    </div>
                  </div>
                  <nav class="mobile-main-navigation clearfix ul-li">
                    <ul
                      id="m-main-nav"
                      class="navbar-nav text-capitalize clearfix"
                    >
                      <li class="dropdown">
                        <a href="#">Home</a>
                        <ul class="dropdown-menu clearfix">
                          <li>
                            <a href="home-articles.html">Articles</a>
                          </li>
                          <li>
                            <a href="home-articles-category.html"
                              >Articles Category</a
                            >
                          </li>
                          <li>
                            <a href="home-articles-category-all.html"
                              >Articles Category All</a
                            >
                          </li>
                          <li>
                            <a href="home-articles-details.html"
                              >Articles Details</a
                            >
                          </li>
                          <li>
                            <a href="home-submit-ticket.html"
                              >Submit Ticket</a
                            >
                          </li>
                          <li>
                            <a href="home-submit-ticket-all.html"
                              >Submit Ticket All</a
                            >
                          </li>
                          <li>
                            <a href="home-customer-ticket.html"
                              >Customer Ticket</a
                            >
                          </li>
                          <li><a href="modal.html">Modal</a></li>
                          <li><a href="signup.html">Sign Up</a></li>
                          <li><a href="login.html">Login</a></li>
                        </ul>
                      </li>
                      <li class="dropdown">
                        <a href="#">Articles</a>
                      </li>
                      <li class="dropdown">
                        <a href="#">My tickets</a>
                      </li>
                      <li class="dropdown">
                        <a href="#">Submit ticket</a>
                      </li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
            <!-- End Mobile Menu -->
          </div>
          <div class="col-lg-3 col-md-4 col-sm-4 col-3 text-end">
            <div class="header-profile cMain-profile position-relative">
              <button
                type="button"
                class="dropdown-toggle headerDropdown"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                <img src="<?php echo e(asset('assets/img/user.png')); ?>" alt="" />
                <h4 class="userName">David Malan</h4>
              </button>
              <ul class="dropdown-menu dropdown-menu-end eDropdown-menu-2">
                <li>
                  <a class="dropdown-item" href="#">
                    <span
                      ><img src="<?php echo e(asset('assets/img/icon/downloads.svg')); ?>" alt=""
                    /></span>
                    Dashboard</a
                  >
                </li>
                <li>
                  <a class="dropdown-item" href="#">
                    <span
                      ><img src="<?php echo e(asset('assets/img/icon/downloads.svg')); ?>" alt=""
                    /></span>
                    Dashboard</a
                  >
                </li>
                <li>
                  <a class="dropdown-item" href="#">
                    <span
                      ><img src="<?php echo e(asset('assets/img/icon/downloads.svg')); ?>" alt=""
                    /></span>
                    Dashboard</a
                  >
                </li>
                <li>
                  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                    <span>
                      <img src="<?php echo e(asset('assets/img/icon/downloads.svg')); ?>" alt="" />
                    </span>
                    Logout
                  </a>
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                  </form>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
<!-- End Main Header --><?php /**PATH C:\xampp\htdocs\creativeitem\resources\views/global/header.blade.php ENDPATH**/ ?>