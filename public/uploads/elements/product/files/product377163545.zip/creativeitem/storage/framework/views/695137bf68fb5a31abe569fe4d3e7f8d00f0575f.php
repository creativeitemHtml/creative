<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/fontawesome/fontawesome.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/daterangepicker/daterangepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/nice-select/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/swiper/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\creativeitem\resources\views/global/include_bottom.blade.php ENDPATH**/ ?>