<?php

if($product->slug == 'academy-lms') {
    $card_color = 'doc-item-academy-LMS';
} else if($product->slug == 'ekattor-7') {
    $card_color = 'doc-item-ekattor';
} else if($product->slug == 'learny-lms') {
    $card_color = 'doc-item-learny-LMS';
} else if($product->slug == 'mastery-lms') {
    $card_color = 'doc-item-mastery-LMS';
} else if($product->slug == 'checkout') {
    $card_color = 'doc-item-checkout';
} else if($product->slug == 'atlas') {
    $card_color = 'doc-item-atlas';
} else if($product->slug == 'ekattor-8') {
    $card_color = 'doc-item-ekattor8';
} else if($product->slug == 'sociopro') {
    $card_color = 'doc-item-academy-LMS';
} else if($product->slug == 'ekushe-crm') {
    $card_color = 'doc-item-mastery-LMS';
} else {
    $card_color = 'doc-item-mastery-LMS';
}

?>

<!-- Title -->
<div class="d-flex justify-content-between align-items-center flex-wrap g-10 mb-30 bd-r-5 bg-white box-shadow-10 py-40 px-30">
    <div class="d-flex align-items-center flex-wrap g-10">
        <a href="javascript:;" class="btn-main edit-project-btn" onclick="defaultModal('<?php echo e(route('admin.create_topic', ['slug' => $product->slug])); ?>', '<?php echo e(get_phrase("Create new topic")); ?>')"><i class="fa-solid fa-add"></i> <?php echo e(get_phrase('Add new topic')); ?></a>
        <a href="#" class="btn-main edit-project-btn"><i class="fa-solid fa-add"></i> <?php echo e(get_phrase('Add new article')); ?></a>
        <a href="#" class="btn-main edit-project-btn"><i class="fa-solid fa-list"></i> <?php echo e(get_phrase('Sort topics')); ?></a>
    </div>
    <div class="d-flex align-items-center flex-wrap g-20">
        <a href="#" class="btn-main back-btn"><i class="fa-solid fa-arrow-left-long"></i> <?php echo e(get_phrase('Back to products')); ?></a>
    </div>
</div>

<div class="bg-white box-shadow-6 pt-26 px-26 pb-30 bd-r-5">
    <div class="row">
        <?php
        $topics = $product->product_to_topic;
        ?>
        <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $articles = $topic->topic_to_article;
        ?>
        <div class="col-lg-3 col-md-3 col-sm-4">
            <div class="doc-item <?php echo e($card_color); ?> d-flex justify-content-between">
                <div class="content">
                    <div class="doc-item-name"><?php echo e($topic->topic); ?></div>
                    <p class="doc-item-article">
                        <i class="fa-solid fa-comment"></i> <?php echo e(count($articles).' '.get_phrase('Articles')); ?>

                    </p>
                    <ul class="pt-2">
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div clsas="doc-item-name"><?php echo e($article->article); ?></div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\creativeitem\resources\views/backend/admin/topics.blade.php ENDPATH**/ ?>