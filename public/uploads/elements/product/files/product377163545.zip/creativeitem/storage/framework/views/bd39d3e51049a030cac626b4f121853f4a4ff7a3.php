<!-- Start Footer -->
<footer>
  <div class="footer-wrap">
    <!-- Codycanyon Info -->
    <div class="codecanyon-info py-60">
      <div class="title-border mb-60">
        <h4>Our CodeCanyon Portfolio</h4>
      </div>
      <div
        class="codecanyon-info-items d-flex justify-content-center justify-content-lg-between align-items-center flex-wrap"
      >
        <div class="codecanyon-info-item">
          <div class="d-flex justify-content-between align-items-center">
            <h4 class="item-no">51</h4>
            <div class="icon">
              <img src="<?php echo e(asset('assets/img/icon/dashboard.svg')); ?>" alt="" />
            </div>
          </div>
          <h4 class="item-title">CodeCanyon Items</h4>
        </div>
        <div class="codecanyon-info-item">
          <div class="d-flex justify-content-between align-items-center">
            <h4 class="item-no">22k</h4>
            <div class="icon">
              <img src="<?php echo e(asset('assets/img/icon/user.svg')); ?>" alt="" />
            </div>
          </div>
          <h4 class="item-title">Downloads</h4>
        </div>
        <div class="codecanyon-info-item">
          <div class="d-flex justify-content-between align-items-center">
            <h4 class="item-no">900+</h4>
            <div class="icon">
              <img src="<?php echo e(asset('assets/img/icon/star.svg')); ?>" alt="" />
            </div>
          </div>
          <h4 class="item-title">5 Star Review</h4>
        </div>
        <div class="codecanyon-info-item">
          <div class="d-flex justify-content-between align-items-center">
            <h4 class="item-no">11</h4>
            <div class="icon">
              <img src="<?php echo e(asset('assets/img/icon/quality.svg')); ?>" alt="" />
            </div>
          </div>
          <h4 class="item-title">Years Experience</h4>
        </div>
      </div>
    </div>
    <!-- Footer Main -->
    <div class="footer-main py-70 bd-t-1 bd-b-1">
      <div class="container">
        <div
          class="row justify-content-start justify-content-md-center justify-content-lg-between"
        >
          <div class="col-lg-2 col-md-4 col-6">
            <div class="f-nav-item">
              <h5 class="f-nav-title">Company</h5>
              <ul class="footer-main-nav d-flex flex-column g-10">
                <li><a href="#">About</a></li>
                <li><a href="#">Job</a></li>
                <li><a href="#">Contact Form</a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-6">
            <div class="f-nav-item pl-lg-42">
              <h5 class="f-nav-title">Projects</h5>
              <ul class="footer-main-nav d-flex flex-column g-10">
                <li><a href="#">WordPress Theme</a></li>
                <li><a href="#">HTML Theme</a></li>
                <li><a href="#">UI Template</a></li>
                <li><a href="#">Helix Framework</a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-2 col-md-4 col-6">
            <div class="f-nav-item pl-lg-16">
              <h5 class="f-nav-title">Supports</h5>
              <ul class="footer-main-nav d-flex flex-column g-10">
                <li><a href="#">Documentation</a></li>
                <li><a href="#">Forums</a></li>
                <li><a href="#">FAQs</a></li>
                <li><a href="#">Support Policy</a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-5 col-md-7">
            <div class="f-nav-item pl-lg-70">
              <h5 class="f-nav-title">Supports</h5>
              <p class="f-nav-text pb-40">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit sed
                do eiusmod tempor incididunt ut labore et dolore magna
                aliqua. Ut enim ad minim.
              </p>
              <div class="subscribe-form mb-30">
                <input
                  type="email"
                  class="form-control"
                  placeholder="Email Address"
                />
                <button class="subscribe-btn">Subscribe</button>
              </div>
              <ul class="social-link-white">
                <li>
                  <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa-brands fa-twitter"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa-brands fa-instagram"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer Bottom -->
    <div class="container">
      <div
        class="footer-bottom py-40 d-flex justify-content-center justify-content-lg-between align-items-center flex-wrap g-20"
      >
        <ul
          class="footer-bottom-nav d-flex justify-content-center justify-content-lg-start align-items-center flex-wrap g-20"
        >
          <li><a href="#">Terms of Use</a></li>
          <li><a href="#">Copyright Notice</a></li>
          <li><a href="#">Refund Policy</a></li>
          <li><a href="#">Privacy Policy</a></li>
        </ul>
        <p class="copy_right">
          &copy; 2011-2022 Creativeitem. All Rights Reserved.
        </p>
      </div>
    </div>
  </div>
</footer>
<!-- End Footer --><?php /**PATH C:\xampp\htdocs\creativeitem\resources\views/global/footer.blade.php ENDPATH**/ ?>