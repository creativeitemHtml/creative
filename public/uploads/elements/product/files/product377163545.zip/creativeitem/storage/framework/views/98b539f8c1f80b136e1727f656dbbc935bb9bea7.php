<!-- Favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>" type="image/x-icon" />

<!-- Bootstrap CSS -->
<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
<!-- fontawesome min CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendors/fontawesome/fontawesome.css')); ?>" />
<!-- Select2 CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendors/select2/select2.min.css')); ?>" />
<!-- Daterangepicker CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendors/daterangepicker/daterangepicker.css')); ?>" />
<!-- Swiper -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendors/swiper/swiper-bundle.min.css')); ?>" />
<!-- Nice select -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendors/nice-select/nice-select.css')); ?>" />
<!-- Main CSS -->
<link href="<?php echo e(asset('assets/scss/style.css')); ?>" rel="stylesheet" /><?php /**PATH C:\xampp\htdocs\creativeitem\resources\views/global/include_top.blade.php ENDPATH**/ ?>