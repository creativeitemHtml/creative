<div class="bg-white box-shadow-6 pt-26 px-26 pb-30 bd-r-5">
	<!-- Title -->
	<div class="d-flex justify-content-end align-items-center flex-wrap g-10 pb-30">
	  <a href="#" class="btn-main new-project-btn"><?php echo e(get_phrase('Create new type')); ?></a>
	</div>
	<!-- Table -->
	<div class="table-responsive">
		<table class="table eTable">
			<!-- Table Head -->
			<thead>
			  <tr>
			    <th scope="col"><?php echo e(get_phrase('Title')); ?></th>
			    <th scope="col"><?php echo e(get_phrase('Identifier')); ?></th>
			    <th scope="col"></th>
			  </tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $product_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
				    <td>
				      <div class="min-w-100">
				        <p class="fz-15-sb-black"><?php echo e($product_type->name); ?></p>
				      </div>
				    </td>
				    <td>
				      	<?php echo e($product_type->identifier); ?>

				    </td>
				    <td>
				      <div class="min-w-100">
				        <a href="#" class="t-btn-one ms-auto"
				          ><?php echo e(get_phrase('Action')); ?></a
				        >
				      </div>
				    </td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<!-- Pagination -->
	<div class="adminPanel-pagi pt-30">
		<?php echo e($product_types->links('pagination::bootstrap-4')); ?>

	</div>
</div><?php /**PATH C:\xampp\htdocs\creativeitem\resources\views/backend/admin/product_type.blade.php ENDPATH**/ ?>