<form method="POST" enctype="multipart/form-data" class="d-block ajaxForm" action="<?php echo e(route('admin.create_topic', ['slug' => $product->slug])); ?>') }}">
    <?php echo csrf_field(); ?>
    <div class="input-wrap mt-2">
        <label for="topic" class="eForm-label"><?php echo e(get_phrase('Topic')); ?></label>
        <input type="text" class="form-control eForm-control" id="topic" name="topic"/>
    </div>
    <div class="mt-2">
        <label for="summary" class="eForm-label"><?php echo e(get_phrase('Summary')); ?></label>
        <textarea name="summary" id="summary" cols="15" rows="3" class="form-control eForm-control"></textarea>
    </div>
    <div class="input-wrap mt-2">
        <label for="thumbnail" class="eForm-label"><?php echo e(get_phrase('Topic thumbnail')); ?></label>( <?php echo e(get_phrase('The image size should be')); ?>: 400 X 255 )
        <input class="form-control eForm-control-file" id="thumbnail" name="thumbnail" onchange="changeTitleOfImageUploader(this)" accept="image/*" type="file" />
    </div>
    <div class="form-check mt-2">
        <input class="form-check-input ciRadio" type="checkbox" name="ciOutlineRadio" id="onlyFree" value="1" checked>
        <label class="form-check-label" for="onlyFree"><?php echo e(get_phrase('Make this topic public')); ?></label>
    </div>
    <div class="text-center float-end mt-4">
        <button type="submit" class="btn btn-primary"><?php echo e(get_phrase('Submit')); ?></button>
    </div>
</form><?php /**PATH C:\xampp\htdocs\creativeitem\resources\views/backend/admin/add_topic.blade.php ENDPATH**/ ?>