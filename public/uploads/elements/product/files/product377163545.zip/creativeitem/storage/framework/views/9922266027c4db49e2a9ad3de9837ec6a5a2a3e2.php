<form method="POST" enctype="multipart/form-data" class="d-block ajaxForm" action="<?php echo e(route('admin.edit_product', ['id' => $product->id])); ?>">
	<?php echo csrf_field(); ?>
    <div class="fpb-7 pt-2">
        <label for="name"><?php echo e(get_phrase('Product title')); ?></label>
        <input type="text" class="form-control eForm-control" name="name" id="name" value="<?php echo e($product->name); ?>" placeholder="<?php echo e(get_phrase('Product name')); ?>" required>
    </div>
    <div class="fpb-7 pt-2">
        <label for="sub_title"><?php echo e(get_phrase('Product subtitle')); ?></label>
        <input type="text" class="form-control eForm-control" name="sub_title" id="sub_title" value="<?php echo e($product->sub_title); ?>" placeholder="<?php echo e(get_phrase('Product subtitle')); ?>" required>
    </div>
    <div class="fpb-7 pt-2">
        <label for="type"><?php echo e(get_phrase('Product type')); ?></label>
        <select class="form-select eForm-select eChoice-multiple-without-remove" name="type" id="type">
            <?php $__currentLoopData = $product_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($product_type->id); ?>" <?php if ($product->product_type_id == $product_type->id) 'selected' ?>><?php echo e(get_phrase($product_type->name)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="fpb-7 pt-2">
        <label><?php echo e(get_phrase('Product thumbnail')); ?></label>
        <div class="input-group">
            <input class="form-control eForm-control-file" id="product-thumbnail" name="thumbnail" onchange="changeTitleOfImageUploader(this)" accept="image/*" type="file" />
        </div>
    </div>

    <div class="fpb-7 pt-2">
        <label><?php echo e(get_phrase('Favicon')); ?></label>
        <div class="input-group">
            <input class="form-control eForm-control-file" id="product-favicon" name="favicon" onchange="changeTitleOfImageUploader(this)" accept="image/*" type="file" />
        </div>
    </div>

    <div class="text-center mt-2">
        <button type="submit" class="btn-main new-project-btn float-end" name="button"><?php echo e(get_phrase('Submit')); ?></button>
    </div>
</form><?php /**PATH C:\xampp\htdocs\creativeitem\resources\views/backend/admin/edit_product.blade.php ENDPATH**/ ?>