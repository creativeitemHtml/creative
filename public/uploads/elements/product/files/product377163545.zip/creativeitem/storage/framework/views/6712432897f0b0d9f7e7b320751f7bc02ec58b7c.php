<?php $__env->startSection('content'); ?>

<!-- Start Login content -->
<section class="section-sign-log">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <!-- Left side -->
            <div class="col-lg-6">
                <div class="sign-log-left d-flex flex-column justify-content-center align-items-center rg-70">
                    <div class="sign-log-img">
                        <img src="<?php echo e(asset('frontend/assets/img/sign-log/relax.png')); ?>" alt="" />
                    </div>
                    <div class="sign-log-benifits">
                        <h4 class="title-24-b pb-30 text-center text-md-start">Include to Joining</h4>
                        <ul class="benifits-items d-flex justify-content-center justify-content-lg-start flex-wrap">
                            <li>Lorem Ipsum available</li>
                            <li>Lorem Ipsum available</li>
                            <li>Lorem Ipsum available</li>
                            <li>Lorem Ipsum available</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Right Side -->
            <div class="col-lg-6">
                <div class="sign-log-right box-shadow-11 p-30 p-sm-40 bd-r-5">
                    <h4 class="title-30-b pb-20">Login to Your Account</h4>
                    <!-- Form -->
                    <form id="login_form" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="signLog-form d-flex flex-column g-10 mb-20">
                            <div class="input-wrap">
                                <label for="email" class="eForm-label" >Username or Email</label>
                                <input id="email" type="email" class="form-control eForm-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" aria-label="Email" required autocomplete="email" autofocus/>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="input-wrap">
                                <label for="password" class="eForm-label" >Password</label>
                                <input id="password" type="password" class="form-control eForm-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" aria-label="Password" name="password" required autocomplete="current-password"/>

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- reCAPTCHA -->
                            <div class="reCAPTCHA"></div>
                            <!-- Remeber me -->
                            <div class="d-flex justify-content-between align-items-center flex-wrap g-10" >
                                <div class="form-check">
                                    <input type="checkbox" name="dl-radio" class="form-check-input custom-radio" id="remember-me" />
                                    <label for="remember-me" class="form-check-label fz-14-m-black" >Remember me</label>
                                </div>
                                <a href="forget-password.html" class="fz-14-m-blue">Forget your password?</a>
                            </div>
                        </div>
                        <!-- Button -->
                        <a href="javascript:;" class="btn-main h_50" onclick="document.getElementById('login_form').submit()">Continue</a>
                    </form>
                    <!-- Separate -->
                    <div class="bd-b-1 pt-20 mb-20"></div>
                    <!-- New account -->
                    <p class="text-center fz-15-sb-black">Don't have an account?
                        <a href="<?php echo e(route('register')); ?>" class="fz-16-sb-blue">Create an Account</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Login content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('global.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\creativeitem\resources\views/auth/login.blade.php ENDPATH**/ ?>