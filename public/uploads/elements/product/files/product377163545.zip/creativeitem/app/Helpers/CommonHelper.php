<?php 
//All common helper functions

// Global Settings
if (!function_exists('get_settings')) {
    function get_settings($key = '', $type='')
    {
        $settings = DB::table('settings')->where('key', $key)->value('value');

        if($type == 'json') {
            $settings = json_decode($settings);
        }

        return $settings;
    }
}

if (! function_exists('phrase')) {
    function phrase($string = '') {
        return $string;
    }
}

if ( ! function_exists('get_all_language'))
{
    function get_all_language(){
        return DB::table('language')->select('name')->distinct()->get();
    }
}

if ( ! function_exists('get_phrase'))
{
    function get_phrase($phrase = '') {

        $active_language = get_settings('language');
        $query = DB::table('language')->where('name', $active_language)->where('phrase', $phrase);
        if($query->get()->count() == 0){
            $translated = $phrase;

            $all_language = get_all_language();

            if($all_language->count() > 0){
                foreach($all_language as $language){

                    if(DB::table('language')->where('name', $language->name)->where('phrase', $phrase)->get()->count() == 0){
                        DB::table('language')->insert(array('name' => $language->name, 'phrase' => $phrase, 'translated' => $translated));
                    }
                }
            }else{
                DB::table('language')->insert(array('name' => 'english', 'phrase' => $phrase, 'translated' => $translated));
            }
            return $translated;
        }
        return $query->value('translated');
    }
}

// RANDOM NUMBER GENERATOR FOR ELSEWHERE
if (!function_exists('random')) {
    function random($length_of_string, $lowercase = false)
    {
        // String of all alphanumeric character
        $str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

        // Shufle the $str_result and returns substring
        // of specified length
        $randVal = substr(str_shuffle($str_result), 0, $length_of_string);
        if($lowercase){
        	$randVal = strtolower($randVal);
        }
        return $randVal;
    }
}

if (!function_exists('slugify')) {
    function slugify($string)
    {
        $string = preg_replace('~[^\\pL\d]+~u', '-', $string);
        $string = trim($string, '-');
        return strtolower($string);
    }
}