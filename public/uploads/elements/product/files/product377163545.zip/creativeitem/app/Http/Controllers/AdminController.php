<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Product;
use App\Models\ProductType;

class AdminController extends Controller
{
    function dashboard()
    {
        $page_data = array();
        return view('backend.admin.dashboard', $page_data);
    }

    function products()
    {
        $page_data = array();
        $page_data['products'] = Product::paginate(6);
        $page_data['page_title'] = 'My Products';
        $page_data['product']='active';
        $page_data['file_name'] = 'products';
        return view('backend.admin.navigation', $page_data);
    }

    function product_type()
    {
        $page_data = array();
        $page_data['product_types'] = ProductType::paginate(10);
        $page_data['page_title'] = 'Product type';
        $page_data['product_type']='active';
        $page_data['file_name'] = 'product_type';
        return view('backend.admin.navigation', $page_data);
    }

    public function create_product(Request $request)
    {
        $page_data = array();

        if(!empty($request->all())) {

            $data = $request->all();

            $page_data['name'] = $data['name'];
            $page_data['sub_title'] = $data['sub_title'];
            $page_data['product_type_id'] = $data['type'];
            $page_data['slug'] = slugify($data['name']);

            // DUPLICATION CHECK
            $duplicate_product_check = Product::get()->where('name', $data['name']);

            if(count($duplicate_product_check) != 0) {
                return redirect()->back()->with('error','Sorry this product already exist');
            }

            if(!empty($data['thumbnail'])){

                $thumbnailName = random(15).'.'.$data['thumbnail']->extension();
    
                $data['thumbnail']->move(public_path('uploads/thumbnails/products/'), $thumbnailName);
    
                $page_data['thumbnail'] = $thumbnailName;
            } else {
                $page_data['thumbnail'] = 'thumbnail.png';
            }

            if(!empty($data['favicon'])){

                $faviconName = random(15).'.'.$data['favicon']->extension();
    
                $data['favicon']->move(public_path('uploads/favicons/products/'), $faviconName);
    
                $page_data['favicon']  = $faviconName;
            } else {
                $page_data['favicon'] = 'favicon.png';
            }

            Product::create($page_data);

            return redirect()->back()->with('message','Product created successfully.');
        }

        $page_data['product_types'] = ProductType::all();

        return view('backend.admin.add_product', $page_data);
    }

    public function edit_product(Request $request, $id = "")
    {
        $page_data = array();

        if(!empty($request->all())) {

            $data = $request->all();

            $page_data['name'] = $data['name'];
            $page_data['sub_title'] = $data['sub_title'];
            $page_data['product_type_id'] = $data['type'];
            $page_data['slug'] = slugify($data['name']);

            $product = Product::find($id);

            if(!empty($data['thumbnail'])){

                $thumbnailName = random(15).'.'.$data['thumbnail']->extension();
    
                $data['thumbnail']->move(public_path('uploads/thumbnails/products/'), $thumbnailName);
    
                $page_data['thumbnail'] = $thumbnailName;
            } else {
                $page_data['thumbnail'] = $product->thumbnail;
            }

            if(!empty($data['favicon'])){

                $faviconName = random(15).'.'.$data['favicon']->extension();
    
                $data['favicon']->move(public_path('uploads/favicons/products/'), $faviconName);
    
                $page_data['favicon']  = $faviconName;
            } else {
                $page_data['favicon'] = $product->favicon;
            }

            Product::where('id', $id)->update($page_data);

            return redirect()->back()->with('message','Product updated successfully.');
        }

        $page_data['product'] = Product::find($id);
        $page_data['product_types'] = ProductType::all();

        return view('backend.admin.edit_product', $page_data);
    }

    public function product_delete($id = "")
    {
        $product = Product::find($id);

        $thumbnailPathName = 'public/uploads/thumbnails/products/' . $product->thumbnail;

        if(file_exists($thumbnailPathName)){
            unlink($thumbnailPathName);
        }

        $faviconPathName = 'public/uploads/favicons/products/' . $product->favicon;

        if(file_exists($faviconPathName)){
            unlink($faviconPathName);
        }

        $product->delete();
        return redirect()->back()->with('message','Product deleted successfully.');
    }

    function documentation()
    {
        $page_data = array();
        $page_data['products'] = Product::paginate(12);
        $page_data['page_title'] = 'Documentation';
        $page_data['documentation']='active';
        $page_data['file_name'] = 'documentation';
        return view('backend.admin.navigation', $page_data);
    }

    function edit_documentation($slug = "")
    {
        $page_data = array();
        $page_data['product'] = Product::where('slug', $slug)->first();
        $page_data['page_title'] = 'Topics and aricles of product : '.$page_data['product']->name;
        $page_data['documentation']='active';
        $page_data['file_name'] = 'topics';
        return view('backend.admin.navigation', $page_data);
    }

    public function create_topic(Request $request, $slug = "")
    {
        $page_data = array();

        if(!empty($request->all())) {

        }
        $page_data['product'] = Product::where('slug', $slug)->first();
        return view('backend.admin.add_topic', $page_data);
    }
}
