<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [ 'id', 'name', 'product_type_id', 'order', 'thumbnail', 'slug', 'sub_title', 'directory', 'favicon' ];

    public function product_to_productType()
    {
        return $this->belongsTo(ProductType::class,'product_type_id','id');
    }

    public function product_to_topic()
    {
        return $this->hasMany(Topic::class,'product_id','id');
    }

    public function product_to_article()
    {
        return $this->hasMany(Article::class,'product_id','id');
    }

}
