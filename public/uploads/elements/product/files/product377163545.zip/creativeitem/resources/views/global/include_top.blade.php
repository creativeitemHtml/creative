<!-- Favicon -->
<link rel="shortcut icon" href="{{ asset('assets/img/favicon.png') }}" type="image/x-icon" />

<!-- Bootstrap CSS -->
<link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" />
<!-- fontawesome min CSS -->
<link rel="stylesheet" href="{{ asset('assets/vendors/fontawesome/fontawesome.css') }}" />
<!-- Select2 CSS -->
<link rel="stylesheet" href="{{ asset('assets/vendors/select2/select2.min.css') }}" />
<!-- Daterangepicker CSS -->
<link rel="stylesheet" href="{{ asset('assets/vendors/daterangepicker/daterangepicker.css') }}" />
<!-- Swiper -->
<link rel="stylesheet" href="{{ asset('assets/vendors/swiper/swiper-bundle.min.css') }}" />
<!-- Nice select -->
<link rel="stylesheet" href="{{ asset('assets/vendors/nice-select/nice-select.css') }}" />
<!-- Main CSS -->
<link href="{{ asset('assets/scss/style.css') }}" rel="stylesheet" />