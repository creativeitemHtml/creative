@php

if($product->slug == 'academy-lms') {
    $card_color = 'doc-item-academy-LMS';
} else if($product->slug == 'ekattor-7') {
    $card_color = 'doc-item-ekattor';
} else if($product->slug == 'learny-lms') {
    $card_color = 'doc-item-learny-LMS';
} else if($product->slug == 'mastery-lms') {
    $card_color = 'doc-item-mastery-LMS';
} else if($product->slug == 'checkout') {
    $card_color = 'doc-item-checkout';
} else if($product->slug == 'atlas') {
    $card_color = 'doc-item-atlas';
} else if($product->slug == 'ekattor-8') {
    $card_color = 'doc-item-ekattor8';
} else if($product->slug == 'sociopro') {
    $card_color = 'doc-item-academy-LMS';
} else if($product->slug == 'ekushe-crm') {
    $card_color = 'doc-item-mastery-LMS';
} else {
    $card_color = 'doc-item-mastery-LMS';
}

@endphp

<!-- Title -->
<div class="d-flex justify-content-between align-items-center flex-wrap g-10 mb-30 bd-r-5 bg-white box-shadow-10 py-40 px-30">
    <div class="d-flex align-items-center flex-wrap g-10">
        <a href="javascript:;" class="btn-main edit-project-btn" onclick="defaultModal('{{ route('admin.create_topic', ['slug' => $product->slug]) }}', '{{ get_phrase("Create new topic") }}')"><i class="fa-solid fa-add"></i> {{ get_phrase('Add new topic') }}</a>
        <a href="#" class="btn-main edit-project-btn"><i class="fa-solid fa-add"></i> {{ get_phrase('Add new article') }}</a>
        <a href="#" class="btn-main edit-project-btn"><i class="fa-solid fa-list"></i> {{ get_phrase('Sort topics') }}</a>
    </div>
    <div class="d-flex align-items-center flex-wrap g-20">
        <a href="#" class="btn-main back-btn"><i class="fa-solid fa-arrow-left-long"></i> {{ get_phrase('Back to products') }}</a>
    </div>
</div>

<div class="bg-white box-shadow-6 pt-26 px-26 pb-30 bd-r-5">
    <div class="row">
        @php
        $topics = $product->product_to_topic;
        @endphp
        @foreach($topics as $topic)
        @php
        $articles = $topic->topic_to_article;
        @endphp
        <div class="col-lg-3 col-md-3 col-sm-4">
            <div class="doc-item {{ $card_color }} d-flex justify-content-between">
                <div class="content">
                    <div class="doc-item-name">{{ $topic->topic }}</div>
                    <p class="doc-item-article">
                        <i class="fa-solid fa-comment"></i> {{ count($articles).' '.get_phrase('Articles') }}
                    </p>
                    <ul class="pt-2">
                        @foreach($articles as $article)
                        <li>
                            <div clsas="doc-item-name">{{ $article->article }}</div>
                        </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>

