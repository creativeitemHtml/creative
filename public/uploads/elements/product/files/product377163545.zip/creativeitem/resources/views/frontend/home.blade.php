@extends('global.index')
@section('content')

<!-- Start Banner -->
<section class="main-home-banner-section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="main-home-banner">
          <div class="content">
            <h3 class="title">Creative Elements</h3>
            <p class="info">The Ultimate UI Subscription</p>
            <div class="d-flex justify-content-center g-30">
              <a href="#" class="main-home-btn"
                ><span>Learn More</span>
                <i class="fa-solid fa-angle-right"></i
              ></a>
              <a href="#" class="main-home-btn"
                ><span>Subscribe</span>
                <i class="fa-solid fa-angle-right"></i
              ></a>
            </div>
          </div>
          <div class="image">
            <img src="{{ asset('frontend/assets/img/main-home-banner.png') }}" alt="" />
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- End Banner -->

<!-- Start All Products -->
<section class="pb-110">
  <div class="container-fluid">
    <div class="featured-products pb-80">
      <div class="row align-items-center">
        <div class="col-lg-6">
          <div class="featured-product featured-product-bg">
            <!-- Graphic -->
            <span class="bg-featured-product">
              <img
                src="{{ asset('frontend/assets/img/product-item/product-bg-graphic.svg') }}"
                alt=""
              />
            </span>
            <!-- Title -->
            <div class="header">
              <h4 class="title">Learny LMS WordPress Plugin</h4>
              <p class="info">
                Lorem Ipsum available, but the majority have suffered
                alteration in some form, by injected humour.
              </p>
              <div class="featured-buttons">
                <a href="#" class="learn-more">Learn More</a>
                <a href="#" class="buy-now">Buy Now</a>
              </div>
            </div>
            <!-- Featured Product -->
            <div class="product">
              <div class="thumb">
                <img
                  src="{{ asset('frontend/assets/img/product-item/product-lg-2.png') }}" alt="" />
              </div>
              <span class="product-price">$45</span>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="featured-product">
            <!-- Graphic -->
            <span class="bg-featured-product">
              <img
                src="{{ asset('frontend/assets/img/product-item/product-graphic.svg') }}"
                alt=""
              />
            </span>
            <!-- Title -->
            <div class="header">
              <h4 class="title">Learny LMS WordPress Plugin</h4>
              <p class="info">
                Lorem Ipsum available, but the majority have suffered
                alteration in some form, by injected humour.
              </p>
              <div class="featured-buttons">
                <a href="#" class="learn-more">Learn More</a>
                <a href="#" class="buy-now">Buy Now</a>
              </div>
            </div>
            <!-- Featured Product -->
            <div class="product">
              <div class="thumb">
                <img
                  src="{{ asset('frontend/assets/img/product-item/product-lg-2.png') }}"
                  alt=""
                />
              </div>
              <span class="product-price">$45</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Buttons -->
    <a href="#" class="view-all-products m-auto"
      >View All Products <i class="fa-solid fa-long-arrow-right"></i
    ></a>
  </div>
</section>
<!-- End All Products -->

<!-- Start We Create -->
<section class="we_create pb-110">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="we_create_left">
          <h4 class="title">
            We create <br />smart solutions <br />for your business.
          </h4>
          <p class="info">
            Lorem Ipsum available, but the majority have suffered alteration
            in some form, by injected humour, or randomised words which
            don't look even slightly believable.
          </p>
          <a href="#" class="btn-yours"
            >Choose yours
            <span><i class="fa-solid fa-long-arrow-right"></i></span
          ></a>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="we_create_right">
          <img src="{{ asset('frontend/assets/img/artwork.png') }}" alt="" />
          <div class="video_icon_wrap">
            <a href="#" class="video_icon">
              <div class="icon"><i class="fa-solid fa-play"></i></div>
              <p class="text">Watch Video</p>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- End We Create -->

<!-- Start Why Best Products -->
<section class="why_best_products">
  <div class="container">
    <!-- Title -->
    <div class="row justify-content-center">
      <div class="col-md-8">
        <div class="best_products">
          <h4 class="title">Why Our Porducts are the best</h4>
          <p class="info">
            Lorem Ipsum available, but the majority have suffered alteration
            in some form injected humour, or randomised words which don't
            look
          </p>
        </div>
      </div>
    </div>
    <!-- Items -->
    <div class="why_best_items">
      <div class="why_best_item">
        <div class="title">
          <div class="icon">
            <img src="{{ asset('frontend/assets/img/why-best/search-alt.svg') }}" alt="" />
          </div>
          <h4>Research</h4>
        </div>
        <p class="info">
          A depth market study is our heart of production. We focus on the
          solution to people's problems.
        </p>
      </div>
      <div class="why_best_item">
        <div class="title">
          <div class="icon">
            <img src="{{ asset('frontend/assets/img/why-best/file.svg') }}" alt="" />
          </div>
          <h4>Documentation</h4>
        </div>
        <p class="info">
          We properly described every single module of our products which
          makes our customer's life easy
        </p>
      </div>
      <div class="why_best_item">
        <div class="title">
          <div class="icon">
            <img src="{{ asset('frontend/assets/img/why-best/life-ring.svg') }}" alt="" />
          </div>
          <h4>Customer Support</h4>
        </div>
        <p class="info">
          Customers can ask us questions anytime, and we are committed to
          answering them on time.
        </p>
      </div>
      <div class="why_best_item">
        <div class="title">
          <div class="icon">
            <img src="{{ asset('frontend/assets/img/why-best/refresh.svg') }}" alt="" />
          </div>
          <h4>Xontinuous Update</h4>
        </div>
        <p class="info">
          Our products are updated with new features and bug fixes
          regularly.
        </p>
      </div>
      <div class="why_best_item">
        <div class="title">
          <div class="icon">
            <img src="{{ asset('frontend/assets/img/why-best/shield.svg') }}" alt="" />
          </div>
          <h4>Data Security</h4>
        </div>
        <p class="info">
          There is no compromise with our customer's data security, even a
          single bit.
        </p>
      </div>
      <div class="why_best_item">
        <div class="title">
          <div class="icon">
            <img src="{{ asset('frontend/assets/img/why-best/ruler-triangle.svg') }}" alt="" />
          </div>
          <h4>Testing</h4>
        </div>
        <p class="info">
          Every release of our products is adequately examined with multiple
          levels concerning bugs and user experience.
        </p>
      </div>
      <div class="why_best_item">
        <div class="title">
          <div class="icon">
            <img src="{{ asset('frontend/assets/img/why-best/head-vr.svg') }}" alt="" />
          </div>
          <h4>Technology</h4>
        </div>
        <p class="info">
          Most advanced technologies are used in our products and has always
          been updated with the latest trends.
        </p>
      </div>
      <div class="why_best_item">
        <div class="title">
          <div class="icon">
            <img src="{{ asset('frontend/assets/img/why-best/user.svg') }}" alt="" />
          </div>
          <h4>Customer first</h4>
        </div>
        <p class="info">
          Customer satisfaction is the heart of our hard work. We do
          whatever it takes to make them happy.
        </p>
      </div>
    </div>
  </div>
</section>
<!-- End Why Best Products -->

<!-- Start Trusted -->
<section class="trusted-section">
  <div class="container">
    <!-- Title -->
    <div class="row">
      <div class="col-lg-12">
        <div class="trusted-title">
          <h4 class="title">
            Trusted by <span>19,000</span> individuals <br />agencies and
            enterprises all over the world.
          </h4>
          <p class="info">
            Lorem Ipsum available, but the majority have suffered alteration
            in some form injected humour, or randomised words which don't
            look
          </p>
        </div>
      </div>
    </div>
    <div class="trusted-items">
      <div class="row">
        <div class="col-md-3 col-sm-6">
          <div class="trusted-item">
            <div class="icon">
              <img src="{{ asset('frontend/assets/img/trusted/crown.svg') }}" alt="" />
            </div>
            <h4 class="title">40+</h4>
            <p class="info">Awesome products</p>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="trusted-item">
            <div class="icon">
              <img src="{{ asset('frontend/assets/img/trusted/ticket.svg') }}" alt="" />
            </div>
            <h4 class="title">23K+</h4>
            <p class="info">Total sales</p>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="trusted-item">
            <div class="icon">
              <img src="{{ asset('frontend/assets/img/trusted/marker.svg') }}" alt="" />
            </div>
            <h4 class="title">11+</h4>
            <p class="info">Years of experience</p>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="trusted-item">
            <div class="icon">
              <img src="{{ asset('frontend/assets/img/trusted/shield-check.svg') }}" alt="" />
            </div>
            <h4 class="title">40+</h4>
            <p class="info">Awesome products</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- End Trusted -->

@endsection