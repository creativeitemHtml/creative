<div class="bg-white box-shadow-6 pt-26 px-26 pb-30 bd-r-5">
	<!-- Title -->
	<div class="d-flex justify-content-end align-items-center flex-wrap g-10 pb-30">
	  <a href="#" class="btn-main new-project-btn">{{ get_phrase('Create new type') }}</a>
	</div>
	<!-- Table -->
	<div class="table-responsive">
		<table class="table eTable">
			<!-- Table Head -->
			<thead>
			  <tr>
			    <th scope="col">{{ get_phrase('Title') }}</th>
			    <th scope="col">{{ get_phrase('Identifier') }}</th>
			    <th scope="col"></th>
			  </tr>
			</thead>
			<tbody>
				@foreach($product_types as $product_type)
				<tr>
				    <td>
				      <div class="min-w-100">
				        <p class="fz-15-sb-black">{{ $product_type->name }}</p>
				      </div>
				    </td>
				    <td>
				      	{{ $product_type->identifier }}
				    </td>
				    <td>
				      <div class="min-w-100">
				        <a href="#" class="t-btn-one ms-auto"
				          >{{ get_phrase('Action') }}</a
				        >
				      </div>
				    </td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	<!-- Pagination -->
	<div class="adminPanel-pagi pt-30">
		{{ $product_types->links('pagination::bootstrap-4') }}
	</div>
</div>