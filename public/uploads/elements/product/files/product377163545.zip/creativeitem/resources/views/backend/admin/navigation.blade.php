@extends('global.index')
@section('content')

@php
isset($product) ? "" : $product ="";
isset($product_type) ? "" : $product_type ="";
isset($documentation) ? "" : $documentation ="";
@endphp

<!-- Start Breadcrumb -->
<section class="breadcrumb-section">
	<div class="breadcrumb-one-graphic-1">
		<img src="{{ asset('assets/img/banner-graphic-1.png') }}" alt="" />
	</div>
	<div class="breadcrumb-one-graphic-2">
		<img src="{{ asset('assets/img/banner-graphic-2.png') }}" alt="" />
	</div>
	<div class="container">
		<div class="row">
			<div class="col-auto offset-3">
				<h3 class="breadcrumb-title">{{ get_phrase($page_title) }}</h3>
			</div>
		</div>
	</div>
</section>
<!-- End Breadcrumb -->

<!-- Start Elements -->
<section class="elements-section breadcrumb-under">
	<div class="container">
	    <!-- Start Textual Inputs -->
	    <div class="row">
		    <!-- Left side -->
		    <div class="col-lg-3 col-md-4 offset-md-3 offset-lg-0">
		        <div class="el_sideber_left">
		        	<!-- Admin Info -->
		        	<div class="admin_user_info d-flex flex-column align-items-center">
			            <div class="user_img">
			            	<img src="{{ asset('assets/img/user.png') }}" alt="" />
			            </div>
			            <div class="user_details d-flex flex-column align-items-center">
							<h3 class="title">{{ auth()->user()->name }}</h3>
							<p class="info">{{ auth()->user()->email }}</p>
			            </div>
		        	</div>
		          	<!-- Start Tab -->
			        <div class="l_sidebar_tab_2 d-flex flex-row flex-lg-column flex-wrap">
			            <div class="sidebar_customer_panel">
			            	<h5 class="tab_title">{{ get_phrase('Admin Panel') }}</h5>
				            <div class="l_sidebarMenu_2">
				                <ul class="nav-links">
				                	<!-- Sidebar menu -->
					                <li class="nav-links-li">
					                    <a href="{{ route('admin.products') }}" class="nav-item {{ $product }} d-flex justify-content-between align-items-center">
					                    	<!-- Icon & Text -->
						                    <div class="icon-link d-flex align-items-center">
						                        <div class="sidebar_icon">
						                        	<svg xmlns="http://www.w3.org/2000/svg" width="16.68" height="17.137" viewBox="0 0 16.68 17.137">
						                                <g id="_x32_98" transform="translate(-1.31 -0.99)">
						                                  <path id="Path_3917" data-name="Path 3917" d="M1.31,3.723V14.274a2.731,2.731,0,0,0,2.725,2.733H9.058a5.563,5.563,0,0,1-.92-3.082,5.651,5.651,0,0,1,5.643-5.643,3.768,3.768,0,0,1,.642.05V3.722A2.736,2.736,0,0,0,11.7.99H4.035A2.731,2.731,0,0,0,1.31,3.722Zm4.809,9.831H4.67a.713.713,0,0,1,0-1.427H6.119a.713.713,0,0,1,0,1.427Zm.756-3.846H4.67a.713.713,0,1,1,0-1.427h2.2a.713.713,0,0,1,0,1.427ZM4.67,4.443h6.385a.713.713,0,1,1,0,1.427H4.67a.713.713,0,1,1,0-1.427Z" transform="translate(0 0)" fill="#a3a8bb"></path>
						                                  <path id="Path_3918" data-name="Path 3918" d="M17.1,13.21a4.209,4.209,0,1,0,4.209,4.217A4.207,4.207,0,0,0,17.1,13.21Zm1.113,5.408a.706.706,0,0,1-1.013,0l-.678-.678a.705.705,0,0,1-.207-.507V15.993a.713.713,0,0,1,1.427,0v1.149l.471.471a.71.71,0,0,1,0,1.006Z" transform="translate(-3.315 -3.502)" fill="#a3a8bb"></path>
						                                </g>
						                            </svg>
						                        </div>
						                        <span class="link_name">{{ get_phrase('Products') }}</span>
						                    </div>
					                    </a>
					                </li>
				                	<li class="nav-links-li">
					                    <a href="{{ route('admin.product_type') }}" class="nav-item {{ $product_type }} d-flex justify-content-between align-items-center">
					                    	<!-- Icon & Text -->
						                    <div class="icon-link d-flex align-items-center">
						                        <div class="sidebar_icon">
						                        	<i class="fa-regular fa-heart"></i>
						                        </div>
						                        <span class="link_name">{{ get_phrase('Product type') }}</span>
						                    </div>
					                    </a>
				                	</li>
				                	<li class="nav-links-li">
					                    <a href="{{ route('admin.documentation') }}" class="nav-item {{ $documentation }} d-flex justify-content-between align-items-center">
					                    	<!-- Icon & Text -->
						                    <div class="icon-link d-flex align-items-center">
						                        <div class="sidebar_icon">
												<svg xmlns="http://www.w3.org/2000/svg" width="16.68" height="17.137" viewBox="0 0 16.68 17.137">
						                                <g id="_x32_98" transform="translate(-1.31 -0.99)">
						                                  <path id="Path_3917" data-name="Path 3917" d="M1.31,3.723V14.274a2.731,2.731,0,0,0,2.725,2.733H9.058a5.563,5.563,0,0,1-.92-3.082,5.651,5.651,0,0,1,5.643-5.643,3.768,3.768,0,0,1,.642.05V3.722A2.736,2.736,0,0,0,11.7.99H4.035A2.731,2.731,0,0,0,1.31,3.722Zm4.809,9.831H4.67a.713.713,0,0,1,0-1.427H6.119a.713.713,0,0,1,0,1.427Zm.756-3.846H4.67a.713.713,0,1,1,0-1.427h2.2a.713.713,0,0,1,0,1.427ZM4.67,4.443h6.385a.713.713,0,1,1,0,1.427H4.67a.713.713,0,1,1,0-1.427Z" transform="translate(0 0)" fill="#a3a8bb"></path>
						                                  <path id="Path_3918" data-name="Path 3918" d="M17.1,13.21a4.209,4.209,0,1,0,4.209,4.217A4.207,4.207,0,0,0,17.1,13.21Zm1.113,5.408a.706.706,0,0,1-1.013,0l-.678-.678a.705.705,0,0,1-.207-.507V15.993a.713.713,0,0,1,1.427,0v1.149l.471.471a.71.71,0,0,1,0,1.006Z" transform="translate(-3.315 -3.502)" fill="#a3a8bb"></path>
						                                </g>
						                            </svg>
						                        </div>
						                        <span class="link_name">{{ get_phrase('Documentation') }}</span>
						                    </div>
					                    </a>
				                	</li>
				                	<li class="nav-links-li">
					                    <a href="#" class="nav-item d-flex justify-content-between align-items-center">
					                    	<!-- Icon & Text -->
						                    <div class="icon-link d-flex align-items-center">
						                        <div class="sidebar_icon">
						                        	<i class="fa-regular fa-heart"></i>
						                        </div>
						                        <span class="link_name">Manage Product</span>
						                    </div>
					                    </a>
				                	</li>
				                	<li class="nav-links-li">
					                    <a href="#" class="nav-item d-flex justify-content-between align-items-center">
					                    	<!-- Icon & Text -->
						                    <div class="icon-link d-flex align-items-center">
						                        <div class="sidebar_icon">
						                        	<svg xmlns="http://www.w3.org/2000/svg" width="18.56" height="17.509" viewBox="0 0 18.56 17.509">
						                                <path id="settings" d="M18.788,8.739c-1.679,0-2.365-1.187-1.53-2.643a1.759,1.759,0,0,0-.649-2.4L15,2.775a1.548,1.548,0,0,0-2.115.557l-.1.176c-.835,1.456-2.207,1.456-3.052,0l-.1-.176a1.522,1.522,0,0,0-2.1-.557l-1.6.918A1.77,1.77,0,0,0,5.283,6.1c.844,1.447.158,2.634-1.521,2.634A1.767,1.767,0,0,0,2,10.5v1.632A1.767,1.767,0,0,0,3.762,13.9c1.679,0,2.365,1.187,1.521,2.643a1.759,1.759,0,0,0,.649,2.4l1.6.918A1.548,1.548,0,0,0,9.652,19.3l.1-.176c.835-1.456,2.207-1.456,3.052,0l.1.176a1.548,1.548,0,0,0,2.115.557l1.6-.918a1.761,1.761,0,0,0,.649-2.4c-.844-1.456-.158-2.643,1.521-2.643a1.767,1.767,0,0,0,1.762-1.762V10.5a1.782,1.782,0,0,0-1.772-1.762Zm-7.513,5.593a3.014,3.014,0,1,1,3.014-3.014A3.02,3.02,0,0,1,11.275,14.332Z" transform="translate(-2 -2.563)" fill="#a3a8bb"></path>
						                            </svg>
						                        </div>
						                        <span class="link_name">Manage Product</span>
						                    </div>
					                    </a>
				                	</li>
				                	<li class="nav-links-li">
					                    <a href="#" class="nav-item d-flex justify-content-between align-items-center">
					                    	<!-- Icon & Text -->
						                    <div class="icon-link d-flex align-items-center">
						                        <div class="sidebar_icon">
						                        	<svg xmlns="http://www.w3.org/2000/svg" width="16.637" height="21.525" viewBox="0 0 16.637 21.525">
						                                <g id="customer-support" transform="translate(-15.218 -5)">
						                                  <path id="Path_3923" data-name="Path 3923" d="M31.725,29.482c-.482-1.434-2.4-2.331-3.77-2.932-.536-.235-2.021-.633-2.2-1.309a1.4,1.4,0,0,1,0-.692,1.338,1.338,0,0,1-.253.025h-.892a1.29,1.29,0,1,1,0-2.58H25.5a1.286,1.286,0,0,1,.8.278,5.74,5.74,0,0,0,.946-.207,8,8,0,0,0,.762-2.636c.291-3.6-1.915-5.7-5.079-5.341a4.24,4.24,0,0,0-3.823,4.188,7.605,7.605,0,0,0,1.571,5.132c.388.533.8.876.733,1.518-.073.76-.885.971-1.466,1.2a16.782,16.782,0,0,0-1.78.89c-1.206.666-2.53,1.468-2.827,2.566-.659,2.432,1.566,3.169,3.4,3.509a27.5,27.5,0,0,0,4.817.314c2.645,0,7.4-.106,8.168-2.094A3.311,3.311,0,0,0,31.725,29.482Z" transform="translate(0 -6.883)" fill="#a3a8bb"></path>
						                                  <path id="Path_3924" data-name="Path 3924" d="M28.922,16.036a.674.674,0,0,0-.564-.307h-.892a.672.672,0,1,0,0,1.344h.892a.666.666,0,0,0,.593-.363,6.031,6.031,0,0,0,3.084-1.038,1.108,1.108,0,0,0,.6.178h.056a1.121,1.121,0,0,0,1.121-1.122V12.486a1.118,1.118,0,0,0-.639-1.01,6.788,6.788,0,0,0-13.562,0,1.117,1.117,0,0,0-.64,1.01v2.241a1.121,1.121,0,0,0,1.12,1.122h.057a1.121,1.121,0,0,0,1.121-1.122V12.486a1.119,1.119,0,0,0-.624-1,5.754,5.754,0,0,1,11.492,0,1.119,1.119,0,0,0-.623,1v2.241a1.127,1.127,0,0,0,.08.417A5.491,5.491,0,0,1,28.922,16.036Z" transform="translate(-2.857)" fill="#a3a8bb"></path>
						                                </g>
						                            </svg>
						                        </div>
						                        <span class="link_name">Manage Product</span>
						                    </div>
					                    </a>
				                	</li>
				                </ul>
				            </div>
			            </div>
			            <a href="#" class="sidebarLogoutBtn">
							<i class="fa-solid fa-arrow-right-from-bracket"></i>
							<span>Logout</span>
			            </a>
			        </div>
		        </div>
		    </div>
		    <!-- Right side -->
		    <div class="col-lg-9">
		    	<!-- Main Content -->
		        @include('backend.admin.'.$file_name)
		    </div>
	    </div>
	    <!-- End Textual Inputs -->
	</div>
</section>
<!-- End Elements -->

@endsection