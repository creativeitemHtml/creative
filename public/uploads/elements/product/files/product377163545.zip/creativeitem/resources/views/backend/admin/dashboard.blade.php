@extends('global.index')
@section('content')

<!-- Start Breadcrumb -->
<section class="breadcrumb-section">
  <div class="breadcrumb-one-graphic-1">
    <img src="{{ asset('assets/img/banner-graphic-1.png') }}" alt="" />
  </div>
  <div class="breadcrumb-one-graphic-2">
    <img src="{{ asset('assets/img/banner-graphic-2.png') }}" alt="" />
  </div>
  <div class="container">
    <div class="row">
      <div class="col-auto offset-3">
        <h3 class="breadcrumb-title">{{ get_phrase('My Products') }}</h3>
      </div>
    </div>
  </div>
</section>
<!-- End Breadcrumb -->

<!-- Start Elements -->
<section class="elements-section breadcrumb-under">
  <div class="container">
    <!-- Start Textual Inputs -->
    <div class="row">
      <!-- Left side -->
      <div class="col-lg-3 col-md-4 offset-md-3 offset-lg-0">
        <div class="el_sideber_left">
          <!-- Admin Info -->
          <div
            class="admin_user_info d-flex flex-column align-items-center"
          >
            <div class="user_img">
              <img src="{{ asset('assets/img/user.png') }}" alt="" />
            </div>
            <div class="user_details d-flex flex-column align-items-center">
              <h3 class="title">David Warner</h3>
              <p class="info">example@info.com</p>
            </div>
          </div>
          <!-- Start Tab -->
          <div
            class="l_sidebar_tab_2 d-flex flex-row flex-lg-column flex-wrap"
          >
            <div class="sidebar_customer_panel">
              <h5 class="tab_title">Admin Panel</h5>
              <div class="l_sidebarMenu_2">
                <ul class="nav-links">
                  <!-- Sidebar menu -->
                  <li class="nav-links-li">
                    <a
                      href="#"
                      class="nav-item active d-flex justify-content-between align-items-center"
                    >
                      <!-- Icon & Text -->
                      <div class="icon-link d-flex align-items-center">
                        <div class="sidebar_icon">
                          <i class="fa-regular fa-heart"></i>
                        </div>
                        <span class="link_name">Manage Product</span>
                      </div>
                    </a>
                  </li>
                  <li class="nav-links-li">
                    <a
                      href="#"
                      class="nav-item d-flex justify-content-between align-items-center"
                    >
                      <!-- Icon & Text -->
                      <div class="icon-link d-flex align-items-center">
                        <div class="sidebar_icon">
                          <i class="fa-regular fa-heart"></i>
                        </div>
                        <span class="link_name">Manage Product</span>
                      </div>
                    </a>
                  </li>
                  <li class="nav-links-li">
                    <a
                      href="#"
                      class="nav-item d-flex justify-content-between align-items-center"
                    >
                      <!-- Icon & Text -->
                      <div class="icon-link d-flex align-items-center">
                        <div class="sidebar_icon">
                          <i class="fa-regular fa-heart"></i>
                        </div>
                        <span class="link_name">Manage Product</span>
                      </div>
                    </a>
                  </li>
                  <li class="nav-links-li">
                    <a
                      href="#"
                      class="nav-item d-flex justify-content-between align-items-center"
                    >
                      <!-- Icon & Text -->
                      <div class="icon-link d-flex align-items-center">
                        <div class="sidebar_icon">
                          <i class="fa-regular fa-heart"></i>
                        </div>
                        <span class="link_name">Manage Product</span>
                      </div>
                    </a>
                  </li>
                  <li class="nav-links-li">
                    <a
                      href="#"
                      class="nav-item d-flex justify-content-between align-items-center"
                    >
                      <!-- Icon & Text -->
                      <div class="icon-link d-flex align-items-center">
                        <div class="sidebar_icon">
                          <i class="fa-regular fa-heart"></i>
                        </div>
                        <span class="link_name">Manage Product</span>
                      </div>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <a href="#" class="sidebarLogoutBtn">
              <i class="fa-solid fa-arrow-right-from-bracket"></i>
              <span>Logout</span>
            </a>
          </div>
        </div>
      </div>
      <!-- Right side -->
      <div class="col-lg-9">
        <!-- Main Content -->
        <div class="bg-white box-shadow-6 pt-26 px-26 pb-30 bd-r-5">
          <!-- Form -->
          <div class="dl_column_form d-flex flex-column rg-22">
            <!-- Title -->
            <div class="row justify-content-between align-items-center">
              <label for="yourTitle" class="col-sm-2 eForm-label"
                >Title</label
              >
              <div class="col-sm-10 col-md-9 col-lg-10">
                <input
                  type="text"
                  class="form-control eForm-control"
                  id="yourTitle"
                  placeholder="Type keyword"
                  aria-label="Type keyword"
                />
              </div>
            </div>
            <!-- Categories -->
            <div class="row justify-content-between align-items-center">
              <label for="categories" class="col-sm-2 eForm-label"
                >Categories</label
              >
              <div class="col-sm-10 col-md-9 col-lg-10">
                <select
                  id="TownCity"
                  class="form-select eForm-select eChoice-multiple-without-remove"
                  data-placeholder="Type to search..."
                >
                  <option value="Select">Select</option>
                  <option value="My Downloads">My Downloads</option>
                  <option value="My Wishlist">My Wishlist</option>
                  <option value="My Subscription">My Subscription</option>
                </select>
              </div>
            </div>
            <!-- Description -->
            <div class="row justify-content-between align-items-start">
              <label for="ciDescription" class="col-sm-2 eForm-label"
                >Description</label
              >
              <div class="col-sm-10 col-md-9 col-lg-10">
                <textarea
                  class="form-control eForm-control el-eForm-control"
                  id="ciDescription"
                  placeholder="Type description"
                ></textarea>
              </div>
            </div>
            <!-- Image -->
            <div class="row justify-content-between align-items-start">
              <label for="ciImage" class="col-sm-2 eForm-label"
                >Image</label
              >
              <div class="col-sm-10 col-md-9 col-lg-10">
                <div class="up-image-upload cam">
                  <img
                    src="{{ asset('assets/img/icon/cloud-arrow-upload.svg') }}"
                    alt=""
                  />
                  <h4 class="title">Click to upload or drag and drop</h4>
                  <p class="info">SVG,PNG,JPG or GIF (max. 500 x 700px)</p>
                </div>
                <div class="multiImageUpload"></div>
              </div>
            </div>
            <!-- Video -->
            <div class="row justify-content-between align-items-startt">
              <label for="ciVideo" class="col-sm-2 eForm-label"
                >Video</label
              >
              <div class="col-sm-10 col-md-9 col-lg-10">
                <div class="cat-create-btn vid videoUpload">Upload</div>
                <div class="multiVideoUpload"></div>
              </div>
            </div>
            <!-- Specification -->
            <div class="row justify-content-between align-items-center">
              <label for="specification" class="col-sm-2 eForm-label"
                >Specification</label
              >
              <div class="col-sm-10 col-md-9 col-lg-10">
                <div class="specification-items">
                  <div class="specification-item">
                    <input
                      type="text"
                      class="form-control eForm-control"
                      id="specificationName"
                      placeholder="Your Name"
                      aria-label="Your Name"
                    />
                  </div>
                  <div class="specification-item">
                    <input
                      type="text"
                      class="form-control eForm-control"
                      id="specificationValance"
                      placeholder="Your Name"
                      aria-label="Your Name"
                    />
                  </div>
                  <div class="specification-item specification-add">
                    <div class="cat-create-btn w-100 h_50">
                      <i class="fa-solid fa-plus"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Price -->
            <div class="row justify-content-between align-items-start">
              <label for="price" class="col-sm-2 eForm-label">Price</label>
              <div class="col-sm-10 col-md-9 col-lg-10">
                <ul class="productPriceOption">
                  <li>
                    <div class="form-check">
                      <input
                        class="form-check-input ciRadio ciRadio-OutlinePrimary"
                        type="radio"
                        name="ciOutlineRadio"
                        id="onlyFree"
                      />
                      <label class="form-check-label" for="onlyFree">
                        Free
                      </label>
                    </div>
                  </li>
                  <li>
                    <div class="form-check">
                      <input
                        class="form-check-input ciRadio ciRadio-OutlinePrimary"
                        type="radio"
                        name="ciOutlineRadio"
                        id="onlyPaid"
                      />
                      <label class="form-check-label" for="onlyPaid">
                        Paid
                      </label>
                      <input
                        type="text"
                        class="form-control eForm-control"
                        id="onlyPaid"
                        placeholder="$00"
                        aria-label="$00"
                      />
                    </div>
                  </li>
                  <li>
                    <div class="form-check">
                      <input
                        class="form-check-input ciRadio ciRadio-OutlinePrimary"
                        type="radio"
                        name="ciOutlineRadio"
                        id="onlySubscription"
                      />
                      <label
                        class="form-check-label"
                        for="onlySubscription"
                      >
                        Only Subscription
                      </label>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <!-- Button -->
          <div class="dl_form_btn d-flex justify-content-end g-20 pt-30">
            <a href="#" class="up-cancel-btn">Cancel</a>
            <a href="#" class="up-uploadFile-btn">Upload file</a>
          </div>
        </div>
      </div>
    </div>
    <!-- End Textual Inputs -->
  </div>
</section>
<!-- End Elements -->
@endsection