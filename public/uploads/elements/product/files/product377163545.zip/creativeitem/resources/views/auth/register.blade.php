@extends('global.index')
@section('content')

<!-- Start Signup content -->
<section class="section-sign-log pt-120 pb-120">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <!-- Left side -->
            <div class="col-lg-6">
                <div class="sign-log-left d-flex flex-column justify-content-center align-items-center rg-70">
                    <div class="sign-log-img">
                        <img src="{{ asset('assets/img/sign-log/relax.png') }}" alt="" />
                    </div>
                    <div class="sign-log-benifits">
                        <h4 class="title-24-b pb-30 text-center text-md-start">
                            Include to Joining
                        </h4>
                        <ul class="benifits-items d-flex justify-content-center justify-content-lg-start flex-wrap">
                            <li>Lorem Ipsum available</li>
                            <li>Lorem Ipsum available</li>
                            <li>Lorem Ipsum available</li>
                            <li>Lorem Ipsum available</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Right Side -->
            <div class="col-lg-6">
                <div class="sign-log-right box-shadow-11 p-40 p-sm-40 bd-r-5">
                    <h4 class="title-30-b pb-40">Create Your Account</h4>
                    <!-- Form -->
                    <form id="register_form" method="POST" action="{{ route('register') }}">
                        @csrf
                        <div class="d-flex flex-column g-20 mb-30">
                            <div class="input-wrap">
                                <label for="name" class="eForm-label">Your Name</label>
                                <input id="name" type="text" class="form-control eForm-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" placeholder="Your Fast Name" aria-label="Your Fast Name" required autocomplete="name" autofocus />

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="input-wrap">
                                <label for="email" class="eForm-label">Email Address</label>
                                <input id="email" type="email" class="form-control eForm-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email"/>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="input-wrap">
                                <label for="password" class="eForm-label">Password</label>
                                <input id="password" type="password" class="form-control eForm-control @error('password') is-invalid @enderror" name="password" placeholder="Password" aria-label="Password" required autocomplete="new-password" />

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="input-wrap">
                                <label for="password" class="eForm-label">Confirm Password</label>
                                <input id="password-confirm" type="password" class="form-control eForm-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                            <!-- reCAPTCHA -->
                            <div class="reCAPTCHA"></div>
                        </div>
                        <!-- Button -->
                        <a href="javascript:;" class="btn-main h_50" onclick="document.getElementById('register_form').submit()">Create my Account</a>
                    </form>
                    <!-- Separate -->
                    <div class="bd-b-1 pt-30 mb-30"></div>
                    <!-- New account -->
                    <p class="text-center fz-16-m-black-2">
                        Already have an account?
                        <a href="{{ route('login') }}" class="fz-16-sb-blue">Login</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Signup content -->
@endsection