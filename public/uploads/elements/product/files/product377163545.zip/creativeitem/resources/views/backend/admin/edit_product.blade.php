<form method="POST" enctype="multipart/form-data" class="d-block ajaxForm" action="{{ route('admin.edit_product', ['id' => $product->id]) }}">
	@csrf
    <div class="fpb-7 pt-2">
        <label for="name">{{ get_phrase('Product title') }}</label>
        <input type="text" class="form-control eForm-control" name="name" id="name" value="{{ $product->name }}" placeholder="{{ get_phrase('Product name') }}" required>
    </div>
    <div class="fpb-7 pt-2">
        <label for="sub_title">{{ get_phrase('Product subtitle') }}</label>
        <input type="text" class="form-control eForm-control" name="sub_title" id="sub_title" value="{{ $product->sub_title }}" placeholder="{{ get_phrase('Product subtitle') }}" required>
    </div>
    <div class="fpb-7 pt-2">
        <label for="type">{{ get_phrase('Product type') }}</label>
        <select class="form-select eForm-select eChoice-multiple-without-remove" name="type" id="type">
            @foreach ($product_types as $key => $product_type)
                <option value="{{ $product_type->id }}" @php if ($product->product_type_id == $product_type->id) 'selected' @endphp>{{ get_phrase($product_type->name) }}</option>
            @endforeach
        </select>
    </div>

    <div class="fpb-7 pt-2">
        <label>{{ get_phrase('Product thumbnail') }}</label>
        <div class="input-group">
            <input class="form-control eForm-control-file" id="product-thumbnail" name="thumbnail" onchange="changeTitleOfImageUploader(this)" accept="image/*" type="file" />
        </div>
    </div>

    <div class="fpb-7 pt-2">
        <label>{{ get_phrase('Favicon') }}</label>
        <div class="input-group">
            <input class="form-control eForm-control-file" id="product-favicon" name="favicon" onchange="changeTitleOfImageUploader(this)" accept="image/*" type="file" />
        </div>
    </div>

    <div class="text-center mt-2">
        <button type="submit" class="btn-main new-project-btn float-end" name="button">{{ get_phrase('Submit') }}</button>
    </div>
</form>