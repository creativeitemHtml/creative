<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="x-ua-compatible" content="ie=edge" />
	<title>Main Home | CREATIVEITEM</title>

	@include('global.include_top')

</head>
<body>

	<!-- Scroll -->
  <div class="scroll-top">
    <i class="fa-solid fa-arrow-up"></i>
  </div>
    
	@include('global.header')

  @yield('content')


  @include('global.footer')

  @include('modal')

	@include('global.include_bottom')
</body>
</html>