<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('assets/vendors/fontawesome/fontawesome.all.min.js') }}"></script>
<script src="{{ asset('assets/vendors/select2/select2.min.js') }}"></script>
<script src="{{ asset('assets/vendors/daterangepicker/daterangepicker.min.js') }}"></script>
<script src="{{ asset('assets/vendors/nice-select/jquery.nice-select.min.js') }}"></script>
<script src="{{ asset('assets/vendors/swiper/swiper-bundle.min.js') }}"></script>
<script src="{{ asset('assets/js/script.js') }}"></script>