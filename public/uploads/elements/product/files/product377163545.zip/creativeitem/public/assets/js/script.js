/* -----------------------------------------------------------------------------
File:           JS Core
Version:        1.0
Last change:    00/00/00 
-------------------------------------------------------------------------------- */
(function ($) {
  "use strict";

  var Medi = {
    init: function () {
      this.Basic.init();
    },

    Basic: {
      init: function () {
        this.scrollTop();
        this.BackgroundImage();
        this.MobileMenu();
        this.NiceSelect();
        this.SelectTwo();
        this.SelectTwoCountry();
        this.ElementsSlider();
        this.Tooltips();
        this.FilterShow();
      },
      scrollTop: function () {
        $(window).on("scroll", function () {
          var ScrollBarPosition = $(this).scrollTop();
          if (ScrollBarPosition > 200) {
            $(".scroll-top").fadeIn();
          } else {
            $(".scroll-top").fadeOut();
          }
        });
        $(".scroll-top").on("click", function () {
          $("body,html").animate({
            scrollTop: 0,
          });
        });
      },
      BackgroundImage: function () {
        $("[data-background]").each(function () {
          $(this).css(
            "background-image",
            "url(" + $(this).attr("data-background") + ")"
          );
        });
      },
      MobileMenu: function () {
        // jQuery(window).on("scroll", function () {
        //   if (jQuery(window).scrollTop() > 250) {
        //     jQuery(".main-header").addClass("sticky-on");
        //   } else {
        //     jQuery(".main-header").removeClass("sticky-on");
        //   }
        // });
        $(".open_mobile_menu").on("click", function () {
          $(".mobile_menu_wrap").toggleClass("mobile_menu_on");
        });
        $(".open_el_mobile_menu").on("click", function () {
          $(".el_mobile_menu_wrap").toggleClass("h-full");
        });
        $(".open_mobile_menu").on("click", function () {
          $("body").toggleClass("mobile_menu_overlay_on");
        });
        if ($(".mobile_menu li.dropdown ul").length) {
          $(".mobile_menu li.dropdown").append(
            '<div class="dropdown-btn"><span class="fa fa-angle-down"></span></div>'
          );
          $(".mobile_menu li.dropdown .dropdown-btn").on("click", function () {
            $(this).prev("ul").slideToggle(500);
          });
        }
      },
      NiceSelect: function () {
        $(document).ready(function () {
          $("select.selectNiceActive").niceSelect();
        });
      },
      SelectTwo: function () {
        // Select2 js
        $(document).ready(function () {
          $(".eChoice-multiple-without-remove").select2({
            placeholder: "Select a state",
          });
        });
        $(document).ready(function () {
          $(".eChoice-multiple-with-remove").select2();
        });
      },
      SelectTwoCountry: function () {
        // For country
        function format(item, state) {
          if (!item.id) {
            return item.text;
          }
          var countryUrl = "https://hatscripts.github.io/circle-flags/flags/";
          var stateUrl = "https://oxguy3.github.io/flags/svg/us/";
          var url = state ? stateUrl : countryUrl;
          var img = $("<img>", {
            class: "img-flag",
            width: 26,
            src: url + item.element.value.toLowerCase() + ".svg",
          });
          var span = $("<span>", {
            text: " " + item.text,
          });
          span.prepend(img);
          return span;
        }

        $(document).ready(function () {
          $("#countries").select2({
            templateResult: function (item) {
              return format(item, false);
            },
          });
          $("#us-states").select2({
            templateResult: function (item) {
              return format(item, true);
            },
          });
        });
      },
      ElementsSlider: function () {
        var swiper = new Swiper(".elSlider-thumb", {
          loop: true,
          spaceBetween: 20,
          slidesPerView: 4,
          freeMode: true,
          watchSlidesProgress: true,
        });
        var swiper2 = new Swiper(".elSlider-main", {
          loop: true,
          spaceBetween: 50,
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
          thumbs: {
            swiper: swiper,
          },
        });
      },
      Tooltips: function () {
        const tooltipTriggerList = document.querySelectorAll(
          '[data-bs-toggle="tooltip"]'
        );
        const tooltipList = [...tooltipTriggerList].map(
          (tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl)
        );
      },
      FilterShow: function () {
        $(".sidebar-title").on("click", function () {
          $(".filter-items").toggleClass("fShow");
        });
      },
    },
  };
  jQuery(document).ready(function () {
    Medi.init();
  });
})(jQuery);
