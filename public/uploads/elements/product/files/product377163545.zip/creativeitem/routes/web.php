<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes(['verify' => true]);

Route::get('/', function () {
    return redirect()->route('home');
});

// Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


Route::controller(AdminController::class)->group(function () {
    Route::get('admin/dashboard', 'dashboard')->name('admin.dashboard');
    Route::get('admin/products', 'products')->name('admin.products');
    Route::get('admin/product_type', 'product_type')->name('admin.product_type');
    Route::any('admin/product/create', 'create_product')->name('admin.create_product');
    Route::any('admin/product/edit/{id}', 'edit_product')->name('admin.edit_product');
    Route::get('admin/product/delete/{id}', 'product_delete')->name('admin.product.delete');
    Route::get('admin/documentation', 'documentation')->name('admin.documentation');
    Route::get('admin/topics/{slug}', 'edit_documentation')->name('admin.edit_documentation');
    Route::any('admin/topics/create/{slug}', 'create_topic')->name('admin.create_topic');
});
