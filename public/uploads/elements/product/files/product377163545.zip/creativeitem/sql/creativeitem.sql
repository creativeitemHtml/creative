-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2023 at 02:00 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `creativeitem`
--

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `ad_dimension_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `short_description` longtext DEFAULT NULL,
  `link_to_click` varchar(300) DEFAULT NULL,
  `ad_image` varchar(255) DEFAULT NULL,
  `ad_type` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `update_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ad_dimentions`
--

CREATE TABLE `ad_dimentions` (
  `id` int(11) NOT NULL,
  `dimension` varchar(100) DEFAULT NULL,
  `horizontal` int(11) DEFAULT NULL,
  `vertical` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` bigint(20) NOT NULL,
  `topic_id` bigint(20) DEFAULT NULL,
  `article` longtext DEFAULT NULL,
  `slug` longtext DEFAULT NULL,
  `visibility` int(11) NOT NULL DEFAULT 1,
  `order` int(11) NOT NULL DEFAULT 0,
  `product_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `topic_id`, `article`, `slug`, `visibility`, `order`, `product_id`, `created_at`, `updated_at`) VALUES
(7, 3, 'What is Ekattor', 'what-is-ekattor', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(45, 28, 'What is Mastery?', 'what-is-mastery', 1, 1, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(46, 28, 'How Mastery LMS works? ', 'how-mastery-lms-works', 1, 2, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(48, 29, 'Technical Details', 'technical-details', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(49, 29, 'System Requirements', 'system-requirements', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(51, 29, 'Installation', 'installation', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(59, 34, 'How Academy works', 'how-academy-works', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(60, 34, 'How to install Academy lms', 'how-to-install-academy-lms', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(61, 34, 'Course website frontend', 'course-website-frontend', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(62, 34, 'Course website backend', 'course-website-backend', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(63, 34, 'Content safety', 'content-safety', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(64, 35, 'How to create a course', 'how-to-create-a-course', 1, 1, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(66, 35, 'How to create a lesson', 'how-to-create-a-lesson', 1, 3, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(68, 35, 'Lesson types', 'lesson-types', 1, 2, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(69, 35, 'How to create a quiz', 'how-to-create-a-quiz', 1, 4, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(70, 35, 'How to create course category', 'how-to-create-course-category', 1, 5, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(71, 35, 'How to create course coupons', 'how-to-create-course-coupons', 1, 6, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(72, 35, 'How to enroll a student manually', 'how-to-enroll-a-student-manually', 1, 7, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(73, 36, 'Browsing the course website', 'browsing-the-course-website', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(74, 36, 'How to purchase a course', 'how-to-purchase-a-course', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(75, 36, 'How to start learning', 'how-to-start-learning', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(76, 36, 'How course progress works', 'how-course-progress-works', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(77, 37, 'Instructor revenue sharing', 'instructor-revenue-sharing', 1, 3, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(78, 37, 'Course sales report', 'course-sales-report', 1, 1, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(79, 38, 'Website setting', 'website-setting', 1, 2, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(80, 38, 'Language settings', 'language-settings', 1, 5, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(81, 38, 'Payment settings', 'payment-settings', 1, 4, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(83, 39, 'Student app', 'student-app', 0, 1, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(84, 39, 'Instructor mobile app', 'instructor-mobile-app', 0, 2, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(86, 40, 'Zoom live class', 'zoom-live-class', 1, 2, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(87, 40, 'Scorm course', 'scorm-course', 1, 3, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(88, 40, 'Amazon S3', 'amazon-s3', 1, 7, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(89, 40, 'Certificate', 'certificate', 1, 8, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(90, 40, 'Offline payment', 'offline-payment', 1, 9, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(91, 40, 'Customer Support ', 'customer-support', 1, 10, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(93, 40, 'Course Analytics ', 'course-analytics', 1, 11, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(94, 40, 'Noticeboard', 'noticeboard', 1, 12, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(95, 40, 'Course Bundle Subscription', 'course-bundle-subscription', 1, 13, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(96, 40, 'Course Forum', 'course-forum', 1, 14, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(97, 40, 'Paytm Payment', 'paytm-payment', 1, 15, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(98, 40, 'Paystack Payment', 'paystack-payment', 1, 16, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(101, 41, 'How to install a theme', 'how-to-install-a-theme', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(102, 41, 'Available themes', 'available-themes', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(103, 31, 'What is Academy LMS', 'what-is-academy-lms', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(104, 5, 'Users of Ekattor', 'users-of-ekattor', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(105, 5, 'Academic terms', 'academic-terms', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(106, 5, 'Exam terms', 'exam-terms', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(107, 5, 'Financial terms', 'financial-terms', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(108, 6, 'System requirement', 'system-requirement', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(109, 6, 'How Ekattor works', 'how-ekattor-works', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(110, 6, 'How to install', 'how-to-install', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(111, 6, 'Website frontend', 'website-frontend', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(112, 6, 'Website backend', 'website-backend', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(113, 6, 'Content safety', 'content-safety', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(114, 7, 'Managing student', 'managing-student', 1, 2, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(115, 7, 'Students admission', 'students-admission', 1, 1, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(116, 7, 'Managing admin', 'managing-admin', 1, 3, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(117, 7, 'Managing teachers', 'managing-teachers', 1, 4, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(118, 7, 'Teachers permission', 'teachers-permission', 1, 5, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(119, 7, 'Managing parents', 'managing-parents', 1, 6, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(122, 7, 'Managing accountant', 'managing-accountant', 1, 7, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(123, 7, 'Managing librarian', 'managing-librarian', 1, 8, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(124, 8, 'Daily attendance', 'daily-attendance', 1, 1, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(125, 8, 'Class routine', 'class-routine', 1, 2, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(127, 8, 'Subject', 'subject', 1, 3, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(128, 8, 'Class', 'class', 1, 5, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(129, 8, 'Classroom', 'classroom', 1, 6, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(130, 8, 'Department', 'department', 1, 7, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(131, 8, 'Event calendar', 'event-calendar', 1, 8, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(132, 9, 'Exam', 'exam', 1, 2, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(133, 9, 'Marks', 'marks', 1, 1, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(134, 9, 'Grade', 'grade', 1, 3, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(135, 9, 'Promotion', 'promotion', 1, 4, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(136, 10, 'How to create academic fees', 'how-to-create-academic-fees', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(137, 10, 'How to pay academic fees', 'how-to-pay-academic-fees', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(138, 10, 'How to manage expenses', 'how-to-manage-expenses', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(139, 10, 'Accounting Reports ', 'accounting-reports', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(141, 10, 'Accountant panel features', 'accountant-panel-features', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(142, 11, 'Library management', 'library-management', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(143, 11, 'Yearly session', 'yearly-session', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(144, 11, 'Noticeboard', 'noticeboard', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(145, 11, 'Addon manager', 'addon-manager', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(146, 13, 'System settings', 'system-settings', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(147, 13, 'Website settings', 'website-settings', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(148, 13, 'School settings', 'school-settings', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(149, 13, 'Payment settings', 'payment-settings', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(150, 13, 'Language settings', 'language-settings', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(151, 13, 'Smtp settings', 'smtp-settings', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(152, 13, 'About', 'about', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(153, 14, 'Monitor academic activities', 'monitor-academic-activities', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(154, 14, 'Pay student fees', 'pay-student-fees', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(155, 15, 'Student assignment', 'student-assignment', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(156, 15, 'Online course', 'online-course', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(157, 15, 'Zoom live class', 'zoom-live-class', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(158, 15, 'Exam marks sender', 'exam-marks-sender', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(159, 15, 'School alumni', 'school-alumni', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(160, 15, 'Student biometric attendance', 'student-biometric-attendance', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(161, 15, 'Multi school', 'multi-school', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(162, 15, 'SMS center', 'sms-center', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(163, 15, 'Student ID card', 'student-id-card', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(164, 8, 'Syllabus', 'syllabus', 1, 4, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(171, 45, 'System and payment settings', 'system-and-payment-settings', 1, 1, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(172, 45, 'Creating category', 'creating-category', 1, 6, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(173, 45, 'Creating sub category', 'creating-sub-category', 1, 7, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(174, 45, 'Creating skills', 'creating-skills', 1, 8, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(175, 45, 'Creating class', 'creating-class', 1, 2, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(176, 45, 'Creating lesson', 'creating-lesson', 1, 3, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(177, 46, 'How to create an account?', 'how-to-create-an-account', 1, 1, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(178, 46, 'How to log in to the Mastery', 'how-to-log-in-to-the-mastery', 1, 2, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(179, 46, 'How to subscribe?', 'how-to-subscribe', 1, 3, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(180, 46, 'How to start a class?', 'how-to-start-a-class', 1, 4, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(181, 46, 'Bookmarking a class', 'bookmarking-a-class', 1, 5, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(182, 46, 'Join the discussion', 'join-the-discussion', 1, 6, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(183, 46, 'Review a class', 'review-a-class', 1, 8, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(184, 45, 'Creating subscription package', 'creating-subscription-package', 1, 9, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(185, 47, 'Opening the mobile app', 'opening-the-mobile-app', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(186, 47, 'How to create an account?', 'how-to-create-an-account', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(187, 47, 'How to sign in to the mobile app?', 'how-to-sign-in-to-the-mobile-app', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(188, 47, 'Bottom navigation bar', 'bottom-navigation-bar', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(189, 47, 'Watch screen', 'watch-screen', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(190, 47, 'Search screen', 'search-screen', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(191, 47, 'My classes screen', 'my-classes-screen', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(192, 47, 'How to subscribe in mobile app?', 'how-to-subscribe-in-mobile-app', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(193, 47, 'My class detail screen', 'my-class-detail-screen', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(194, 47, 'Follow and unfollow instructor', 'follow-and-unfollow-instructor', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(195, 47, 'How to visit instructor profile?', 'how-to-visit-instructor-profile', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(196, 47, 'How to visit My Profile?', 'how-to-visit-my-profile', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(197, 16, 'How to install Ekattor', 'how-to-install-ekattor', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(198, 16, 'How to admit student in Ekattor', 'how-to-admit-student-in-ekattor', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(199, 16, 'How to take attendance in Ekattor', 'how-to-take-attendance-in-ekattor', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(200, 16, 'How to manage class routine and syllabus in Ekattor', 'how-to-manage-class-routine-and-syllabus-in-ekattor', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(201, 16, 'How to manage class and subject in Ekattor', 'how-to-manage-class-and-subject-in-ekattor', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(202, 16, 'How to manage class room and department in Ekattor', 'how-to-manage-class-room-and-department-in-ekattor', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(203, 16, 'How to manage event calendar in Ekattor', 'how-to-manage-event-calendar-in-ekattor', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(204, 16, 'How to manage exam & marks in Ekattor', 'how-to-manage-exam-marks-in-ekattor', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(205, 45, 'How to create an instructor?', 'how-to-create-an-instructor', 1, 4, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(206, 48, 'System settings', 'system-settings', 1, 1, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(207, 48, 'Website settings', 'website-settings', 1, 2, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(208, 48, 'Payment settings', 'payment-settings', 1, 4, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(209, 48, 'Language settings', 'language-settings', 1, 5, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(210, 48, 'Smtp settings', 'smtp-settings', 1, 6, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(211, 48, 'About', 'about', 1, 7, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(212, 49, 'How to get an instructor account?', 'how-to-get-an-instructor-account', 1, 1, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(213, 49, 'How to login to this application?', 'how-to-login-to-this-application', 1, 2, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(214, 49, 'How to create a class?', 'how-to-create-a-class', 1, 3, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(215, 49, 'How to add a lesson?', 'how-to-add-a-lesson', 1, 4, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(217, 45, 'How to create a student', 'how-to-create-a-student', 1, 5, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(218, 51, 'Mastery Flutter App', 'mastery-flutter-app', 0, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(221, 37, 'Instructor payout processing', 'instructor-payout-processing', 1, 4, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(222, 38, 'System settings', 'system-settings', 1, 1, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(223, 38, 'SMTP settings', 'smtp-settings', 1, 6, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(224, 38, 'Social login', 'social-login', 1, 7, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(225, 38, 'About', 'about', 1, 10, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(226, 37, 'Instructor permission', 'instructor-permission', 1, 2, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(228, 42, 'Installing the Academy LMS', 'installing-the-academy-lms', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(229, 42, 'How to create a course in Academy LMS', 'how-to-create-a-course-in-academy-lms', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(231, 42, 'How to sort lessons by drag and drop in Academy LMS', 'how-to-sort-lessons-by-drag-and-drop-in-academy-lms', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(232, 42, 'How to manage quiz in Academy LMS', 'how-to-manage-quiz-in-academy-lms', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(233, 42, 'How students purchase course in Academy LMS', 'how-students-purchase-course-in-academy-lms', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(277, 40, 'CCAvenue Payment ', 'ccavenue-payment', 1, 17, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(279, 48, 'Student enrolment settings', 'student-enrolment-settings', 1, 3, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(280, 66, 'How revenue sharing works', 'how-revenue-sharing-works', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(281, 46, 'How to upload a project?', 'how-to-upload-a-project', 1, 7, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(282, 49, 'Payout reports', 'payout-reports', 1, 5, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(284, 66, 'Revenue reports', 'revenue-reports', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(285, 67, 'Student mobile application', 'student-mobile-application', 1, 1, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(287, 67, 'Manage account with mobile app', 'manage-account-with-mobile-app', 1, 2, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(288, 67, 'Purchasing course with mobile app', 'purchasing-course-with-mobile-app', 1, 3, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(289, 67, 'Managing wishlist in mobile app', 'managing-wishlist-in-mobile-app', 1, 4, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(290, 67, 'Course play with mobile app', 'course-play-with-mobile-app', 1, 5, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(291, 67, 'Join live class with mobile app', 'join-live-class-with-mobile-app', 1, 6, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(292, 67, 'Offline course play for mobile app', 'offline-course-play-for-mobile-app', 1, 7, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(294, 68, 'What is Checkout', 'what-is-checkout', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(299, 70, 'How does Checkout work', 'how-does-checkout-work', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(300, 70, 'How to install Checkout ', 'how-to-install-checkout', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(301, 70, 'Checkout website', 'checkout-website', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(302, 70, 'Content Safety', 'content-safety', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(303, 71, 'How to add a product', 'how-to-add-a-product', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(304, 71, 'How to create a unit', 'how-to-create-a-unit', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(305, 72, 'How to create a category', 'how-to-create-a-category', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(306, 72, 'How to create a sub-category', 'how-to-create-a-sub-category', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(308, 73, 'How to add a customer manually', 'how-to-add-a-customer-manually', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(309, 73, 'How to add a delivery boy', 'how-to-add-a-delivery-boy', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(310, 73, 'Customer Support', 'customer-support', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(312, 75, 'System settings', 'system-settings', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(313, 75, 'Store settings', 'store-settings', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(314, 75, 'Language settings', 'language-settings', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(315, 75, 'Payment settings', 'payment-settings', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(316, 75, 'SMTP settings', 'smtp-settings', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(317, 75, 'About', 'about', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(318, 76, 'How to update profile info', 'how-to-update-profile-info', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(319, 76, 'How to change password', 'how-to-change-password', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(320, 77, 'Customer mobile application', 'customer-mobile-application', 1, 1, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(332, 81, 'Pending Orders', 'pending-orders', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(333, 81, 'Orders Processing', 'orders-processing', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(334, 81, 'Delivered Orders', 'delivered-orders', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(335, 81, 'Canceled Orders', 'canceled-orders', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(336, 72, 'How to create a sub-sub-category', 'how-to-create-a-sub-sub-category', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(337, 77, 'Account creation and sign in with the mobile app', 'account-creation-and-sign-in-with-the-mobile-app', 1, 2, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(338, 77, 'Purchasing product with mobile app', 'purchasing-product-with-mobile-app', 1, 3, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(339, 77, 'Managing wishlist in mobile app', 'managing-wishlist-in-mobile-app', 1, 4, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(340, 77, 'Tracking my orders list in the customer app', 'tracking-my-orders-list-in-the-customer-app', 1, 5, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(342, 77, 'Help and Support with mobile app', 'help-and-support-with-mobile-app', 1, 7, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(347, 77, 'Manage account with mobile apps', 'manage-account-with-mobile-apps', 1, 6, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(357, 86, 'Delivery boy mobile application', 'delivery-boy-mobile-application', 1, 1, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(358, 86, 'Update order status with mobile app', 'update-order-status-with-mobile-app', 1, 3, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(359, 86, 'Delivered order list in mobile app', 'delivered-order-list-in-mobile-app', 1, 4, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(360, 86, 'Manage account with mobile app', 'manage-account-with-mobile-app', 1, 5, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(361, 81, 'Payment history', 'payment-history', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(362, 86, 'Sign in with the mobile application', 'sign-in-with-the-mobile-application', 1, 2, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(363, 87, 'All about Learny LMS', 'all-about-learny-lms', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(364, 87, 'Quick start guide', 'quick-start-guide', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(365, 87, 'Basic terms ', 'basic-terms', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(366, 87, 'Content safety', 'content-safety', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(367, 88, 'How Learny works', 'how-learny-works', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(368, 88, 'How to install Learny', 'how-to-install-learny', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(369, 88, 'Learny license activation', 'learny-license-activation', 0, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(370, 88, 'Installing third-party plugins', 'installing-third-party-plugins', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(371, 88, 'Configuring Learny', 'configuring-learny', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(372, 89, 'Course instructors', 'course-instructors', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(373, 89, 'Course students', 'course-students', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(374, 90, 'Creating a course', 'creating-a-course', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(375, 90, 'Managing course curriculum', 'managing-course-curriculum', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(376, 90, 'Organizing course curriculum', 'organizing-course-curriculum', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(377, 90, 'Creating course category', 'creating-course-category', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(378, 90, 'Managing course tags', 'managing-course-tags', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(379, 61, 'Admin revenue report', 'admin-revenue-report', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(380, 61, 'Instructor revenue report', 'instructor-revenue-report', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(381, 61, 'Instructor payout report', 'instructor-payout-report', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(382, 61, 'Instructor revenue sharing', 'instructor-revenue-sharing', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(384, 61, 'Instructor payout process', 'instructor-payout-process', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(385, 91, 'Import Learny courses to WooCommerce products', 'import-learny-courses-to-woocommerce-products', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(386, 91, 'How to sync WooCommerce orders to Learny LMS', 'how-to-sync-woocommerce-orders-to-learny-lms', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(387, 92, 'Adding various course list using Elementor', 'adding-various-course-list-using-elementor', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(388, 92, 'Adding counter block using Elementor', 'adding-counter-block-using-elementor', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(389, 92, 'Adding category list using Elementor', 'adding-category-list-using-elementor', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(390, 93, 'Course creation', 'course-creation', 1, 1, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(391, 93, 'Payout report and requesting for new payout (Old)', 'payout-report-and-requesting-for-new-payout-old', 0, 5, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(392, 93, 'Course revenue report (Old)', 'course-revenue-report-old', 0, 6, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(394, 94, 'How to purchase a course', 'how-to-purchase-a-course', 1, 2, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(395, 94, 'My course ', 'my-course', 1, 3, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(397, 94, 'Purchase history', 'purchase-history', 1, 5, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(398, 94, 'How to start learning', 'how-to-start-learning', 1, 6, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(399, 94, 'How course progress work', 'how-course-progress-work', 1, 7, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(400, 94, 'Wishlist', 'wishlist', 1, 4, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(401, 67, 'Join course forum with mobile app', 'join-course-forum-with-mobile-app', 1, 8, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(402, 67, 'Purchasing course bundle with mobile app', 'purchasing-course-bundle-with-mobile-app', 1, 9, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(403, 67, 'Course play from my bundles in mobile app', 'course-play-from-my-bundles-in-mobile-app', 1, 10, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(405, 28, 'Basic terms', 'basic-terms', 1, 3, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(406, 68, 'Basic terms', 'basic-terms', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(407, 31, 'Basic terms', 'basic-terms', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(408, 93, 'Course curriculum', 'course-curriculum', 1, 2, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(417, 39, 'Managing account with mobile app', 'managing-account-with-mobile-app', 1, 4, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(418, 39, 'Managing courses with the mobile app', 'managing-courses-with-the-mobile-app', 1, 6, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(419, 39, 'Create a new course with the mobile app', 'create-a-new-course-with-the-mobile-app', 1, 5, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(420, 39, 'Managing sales reports with the mobile app', 'managing-sales-reports-with-the-mobile-app', 1, 7, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(421, 39, 'Managing payout report with the mobile app', 'managing-payout-report-with-the-mobile-app', 1, 8, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(422, 39, 'Instructor mobile application', 'instructor-mobile-application', 1, 3, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(424, 93, 'Requesting a payout', 'requesting-a-payout', 1, 4, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(425, 93, 'Course revenue report', 'course-revenue-report', 1, 3, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(426, 94, 'Browsing the course', 'browsing-the-course', 1, 1, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(427, 40, 'Ebook', 'ebook', 1, 4, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(428, 40, 'Assignment', 'assignment', 1, 6, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(429, 95, 'How it works', 'how-it-works', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(430, 65, 'How to update Learny LMS Pro?', 'how-to-update-learny-lms-pro', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(431, 95, 'Admin panel', 'admin-panel', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(432, 95, 'Instructor panel', 'instructor-panel', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(433, 95, 'Student panel', 'student-panel', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(434, 95, 'How to get Zoom API & Secret keys', 'how-to-get-zoom-api-secret-keys', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(435, 96, 'What is Atlas', 'what-is-atlas', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(436, 96, 'Basic terms', 'basic-terms', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(437, 97, 'How Atlas works', 'how-atlas-works', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(438, 97, 'How to install Atlas', 'how-to-install-atlas', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(439, 97, 'Website frontend', 'website-frontend', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(440, 97, 'Website backend', 'website-backend', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(442, 97, 'Content Safety', 'content-safety', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(443, 98, 'How to add the directory', 'how-to-add-the-directory', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(444, 98, 'How to add categories', 'how-to-add-categories', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(445, 98, 'How to add amenities', 'how-to-add-amenities', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(446, 98, 'Blog managing', 'blog-managing', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(447, 98, 'Bookings requests', 'bookings-requests', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(448, 98, 'How to add cities', 'how-to-add-cities', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(449, 98, 'Ratings', 'ratings', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(450, 98, 'Managing users', 'managing-users', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(451, 99, 'System settings', 'system-settings', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(452, 99, 'Frontend settings', 'frontend-settings', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(453, 99, 'Map settings', 'map-settings', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(454, 99, 'Payment settings', 'payment-settings', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(455, 99, 'Language settings', 'language-settings', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(456, 99, 'SMTP settings', 'smtp-settings', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(457, 99, 'About', 'about', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(458, 100, 'Pricing ', 'pricing', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(459, 100, 'Offline payment', 'offline-payment', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(460, 100, 'Payment history', 'payment-history', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(461, 101, 'How to add customer\'s directory', 'how-to-add-customer-s-directory', 1, 2, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(462, 101, 'Customer booking requests', 'customer-booking-requests', 1, 4, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(463, 101, 'Plan & history', 'plan-history', 1, 5, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(464, 101, 'Wishlist', 'wishlist', 1, 6, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(465, 101, 'Customer\'s account management', 'customer-s-account-management', 1, 7, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(466, 102, 'Online shop', 'online-shop', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(467, 102, 'Facebook chat', 'facebook-chat', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(468, 101, 'How to purchase a plan', 'how-to-purchase-a-plan', 1, 1, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(469, 94, 'How to unlock drip content lesson', 'how-to-unlock-drip-content-lesson', 1, 8, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(470, 35, 'Multi admin', 'multi-admin', 1, 8, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(471, 38, 'Drip content settings', 'drip-content-settings', 1, 3, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(472, 36, 'How to unlock drip content lesson', 'how-to-unlock-drip-content-lesson', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(473, 101, 'How to claim and report a directory', 'how-to-claim-and-report-a-directory', 1, 3, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(474, 98, 'Admin\'s account management', 'admin-s-account-management', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(475, 105, 'How to generate a certificate', 'how-to-generate-a-certificate', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(476, 105, 'How to download a certificate', 'how-to-download-a-certificate', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(478, 34, 'Drip content', 'drip-content', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(479, 90, 'Drip content', 'drip-content', 1, 0, 3, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(480, 34, 'Device access limitation', 'device-access-limitation', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(481, 34, 'Quiz', 'quiz', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(482, 36, 'How to complete the quiz', 'how-to-complete-the-quiz', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(483, 38, 'Dynamic page building ', 'dynamic-page-building', 1, 8, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(484, 40, 'Affiliate addon', 'affiliate-addon', 1, 1, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(485, 106, 'Academy LMS affiliate addon', 'academy-lms-affiliate-addon', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(486, 43, 'How to update the application version', 'how-to-update-the-application-version', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(487, 17, 'How to update the application version', 'how-to-update-the-application-version', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(489, 107, 'How to update the application version', 'how-to-update-the-application-version', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(490, 108, 'How to update the application version', 'how-to-update-the-application-version', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(491, 104, 'How to update the application version', 'how-to-update-the-application-version', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(492, 40, 'iyzico Payment', 'iyzico-payment', 1, 18, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(493, 43, 'How to integrate your customization features after updating the application?', 'how-to-integrate-your-customization-features-after-updating-the-application', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(494, 17, 'How to integrate your customization features after updating the application?', 'how-to-integrate-your-customization-features-after-updating-the-application', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(495, 107, 'How to integrate your customization features after updating the application?', 'how-to-integrate-your-customization-features-after-updating-the-application', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(496, 108, 'How to integrate your customization features after updating the application?', 'how-to-integrate-your-customization-features-after-updating-the-application', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(497, 104, 'How to integrate your customization features after updating the application?', 'how-to-integrate-your-customization-features-after-updating-the-application', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(498, 43, 'What kind of license should I purchase?', 'what-kind-of-license-should-i-purchase', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(499, 17, 'What kind of license should I purchase?', 'what-kind-of-license-should-i-purchase', 1, 0, 2, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(500, 107, 'What kind of license should I purchase?', 'what-kind-of-license-should-i-purchase', 1, 0, 4, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(501, 108, 'What kind of license should I purchase?', 'what-kind-of-license-should-i-purchase', 1, 0, 5, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(502, 104, 'What kind of license should I purchase?', 'what-kind-of-license-should-i-purchase', 1, 0, 6, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(503, 109, 'Configuring Blog Settings', 'configuring-blog-settings', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(504, 109, 'Managing Blog Category', 'managing-blog-category', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(505, 109, 'How to Publish a Blog (Admin)', 'how-to-publish-a-blog-admin', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(506, 109, 'How to Publish a Blog (Instructor)', 'how-to-publish-a-blog-instructor', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(507, 110, 'What is Video Subscription Service in Academy LMS', 'what-is-video-subscription-service-in-academy-lms', 1, 1, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(508, 110, 'How to purchase a package from Video Subscription Service', 'how-to-purchase-a-package-from-video-subscription-service', 1, 2, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(509, 110, 'Configuring the video subscription service with your application', 'configuring-the-video-subscription-service-with-your-application', 1, 3, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(510, 110, 'Adding videos to the subscription service', 'adding-videos-to-the-subscription-service', 1, 4, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(511, 110, 'Managing my videos on the Video Subscription Service', 'managing-my-videos-on-the-video-subscription-service', 1, 5, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(512, 110, 'Managing my subscription packages on the Video Subscription Service', 'managing-my-subscription-packages-on-the-video-subscription-service', 1, 6, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(513, 110, 'Managing domain in the Video Subscription Service', 'managing-domain-in-the-video-subscription-service', 1, 7, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(514, 110, 'Managing my profile', 'managing-my-profile', 1, 8, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(576, 123, 'What is Ekattor 8', 'what-is-ekattor-8', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(577, 124, 'Users of Ekattor 8', 'users-of-ekattor-8', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(578, 124, 'Ekattor 8 terms', 'ekattor-8-terms', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(580, 125, 'System requirement', 'system-requirement', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(581, 125, 'How Ekattor 8 works', 'how-ekattor-8-works', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(582, 125, 'How to install', 'how-to-install', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(583, 125, 'Website backend', 'website-backend', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(584, 125, 'Managing schools ', 'managing-schools', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(585, 125, 'Package', 'package', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(586, 125, 'Content safety  ', 'content-safety', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(587, 126, 'Offline admission', 'offline-admission', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(588, 126, 'Managing students', 'managing-students', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(589, 126, 'Managing admin', 'managing-admin', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(590, 126, 'Managing teachers', 'managing-teachers', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(591, 126, 'Teacher’s permission', 'teacher-s-permission', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(592, 126, 'Managing parents', 'managing-parents', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(593, 126, 'Managing accountant', 'managing-accountant', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(594, 126, 'Managing librarian', 'managing-librarian', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(595, 127, 'Daily attendance', 'daily-attendance', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(596, 127, 'Class routine', 'class-routine', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(597, 127, 'Subject', 'subject', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(598, 127, 'Syllabus', 'syllabus', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(599, 127, 'Class', 'class', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(600, 127, 'Classroom', 'classroom', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(601, 127, 'Department', 'department', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(602, 127, 'Grade book', 'grade-book', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(603, 128, 'Exam category', 'exam-category', 1, 5, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(604, 128, 'Offline Exam', 'offline-exam', 1, 1, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(605, 128, 'Marks', 'marks', 1, 2, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(606, 128, 'Promotion', 'promotion', 1, 3, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(607, 128, 'Grade ', 'grade', 1, 4, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(608, 129, 'How to create academic fees', 'how-to-create-academic-fees', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(609, 129, 'How to pay academic fees', 'how-to-pay-academic-fees', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(610, 129, 'Expense Categories', 'expense-categories', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(611, 129, 'How to manage expenses ', 'how-to-manage-expenses', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(612, 129, 'Offline payment request', 'offline-payment-request', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(613, 130, 'Book list manager', 'book-list-manager', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(614, 130, 'Book issue report', 'book-issue-report', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(615, 130, 'Event ', 'event', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(617, 130, 'Package managing', 'package-managing', 0, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(618, 130, 'Subscription', 'subscription', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(620, 131, 'School Settings', 'school-settings', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(621, 131, 'System settings', 'system-settings', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(622, 131, 'Language settings', 'language-settings', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(623, 131, 'Payment settings (Superadmin)', 'payment-settings-superadmin', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(624, 131, 'SMTP settings', 'smtp-settings', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(625, 131, 'About', 'about', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(626, 131, 'Payment settings (Admin)', 'payment-settings-admin', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(627, 132, 'Monitor users', 'monitor-users', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(628, 132, 'Monitor academic activities', 'monitor-academic-activities', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(629, 132, 'Monitor examination activities', 'monitor-examination-activities', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(630, 132, 'Paying fees', 'paying-fees', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(634, 133, 'HR addon bundles', 'hr-addon-bundles', 1, 3, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(637, 134, 'Version log', 'version-log', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(638, 125, 'Quick start guide', 'quick-start-guide', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(641, 134, 'How to integrate your customization features after updating the application?', 'how-to-integrate-your-customization-features-after-updating-the-application', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(642, 134, 'What kind of license should I purchase?', 'what-kind-of-license-should-i-purchase', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(643, 131, 'Yearly session', 'yearly-session', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(647, 133, 'Addon bundel manager', 'addon-bundel-manager', 1, 1, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(648, 133, 'How to install addon bundle', 'how-to-install-addon-bundle', 1, 2, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(649, 133, 'Online addon bundle', 'online-addon-bundle', 1, 4, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(650, 133, 'Finance addon bundle', 'finance-addon-bundle', 1, 5, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(651, 130, 'Noticeboard', 'noticeboard', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(652, 140, 'What is Sociopro', 'what-is-sociopro', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(653, 140, 'Basic terms', 'basic-terms', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(654, 141, 'How to install Sociopro', 'how-to-install-sociopro', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(655, 141, 'Content safety', 'content-safety', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(656, 142, 'Sign up', 'sign-up', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(657, 142, 'Log in', 'log-in', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(658, 142, 'Managing password', 'managing-password', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(659, 143, 'Post management (Timeline)', 'post-management-timeline', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(660, 143, 'Post sharing', 'post-sharing', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(661, 143, 'Tagging people', 'tagging-people', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(662, 143, 'Live video', 'live-video', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(663, 143, 'How to react & comment on a post', 'how-to-react-comment-on-a-post', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(664, 144, 'Post management (Profile)', 'post-management-profile', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(665, 144, 'Profile picture', 'profile-picture', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(666, 144, 'Cover photo', 'cover-photo', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(667, 144, 'Tagging people', 'tagging-people', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(668, 144, 'Live video', 'live-video', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(669, 144, 'Managing friends', 'managing-friends', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(670, 144, 'Photos and Albums', 'photos-and-albums', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(671, 144, 'Videos', 'videos', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(673, 144, 'Personal details', 'personal-details', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(674, 145, 'Group creating', 'group-creating', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(675, 145, 'Group invitation', 'group-invitation', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(676, 145, 'Group discussion', 'group-discussion', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30');
INSERT INTO `articles` (`id`, `topic_id`, `article`, `slug`, `visibility`, `order`, `product_id`, `created_at`, `updated_at`) VALUES
(677, 145, 'Group members', 'group-members', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(678, 145, 'How to manage a group album', 'how-to-manage-a-group-album', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(679, 145, 'Live video in the group', 'live-video-in-the-group', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(681, 146, 'Page creating', 'page-creating', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(682, 146, 'Post sharing (Page)', 'post-sharing-page', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(683, 146, 'Page profile image', 'page-profile-image', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(684, 146, 'Page cover image', 'page-cover-image', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(685, 146, 'How to manage page album', 'how-to-manage-page-album', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(686, 146, 'Live videos on Page', 'live-videos-on-page', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(688, 146, 'Suggested Pages', 'suggested-pages', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(689, 146, 'Liked Pages', 'liked-pages', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(690, 147, 'Blog creating', 'blog-creating', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(691, 147, 'My Articles', 'my-articles', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(692, 147, 'Blog managing', 'blog-managing', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(693, 148, 'Creating event', 'creating-event', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(694, 148, 'My Event', 'my-event', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(695, 148, 'Event managing', 'event-managing', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(696, 149, 'Creating videos and shorts', 'creating-videos-and-shorts', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(697, 149, 'Managing videos', 'managing-videos', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(698, 149, 'Managing shorts', 'managing-shorts', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(699, 150, 'Adding products', 'adding-products', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(700, 150, 'My products', 'my-products', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(701, 150, 'Purchasing products from the Sociopro marketplace', 'purchasing-products-from-the-sociopro-marketplace', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(702, 150, 'Saving a product from the Sociopro marketplace', 'saving-a-product-from-the-sociopro-marketplace', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(703, 150, 'Sharing products from the Sociopro marketplace', 'sharing-products-from-the-sociopro-marketplace', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(704, 151, 'Adding stories', 'adding-stories', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(705, 152, 'Page category', 'page-category', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(706, 152, 'Marketplace', 'marketplace', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(707, 152, 'Blogs', 'blogs', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(708, 152, 'Ads', 'ads', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(709, 152, 'Managing reported post', 'managing-reported-post', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(710, 153, 'System settings', 'system-settings', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(711, 153, 'Custom page', 'custom-page', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(712, 153, 'SMTP settings', 'smtp-settings', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(713, 153, 'About', 'about', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(714, 154, 'How to send messages', 'how-to-send-messages', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(715, 154, 'How to see my notifications', 'how-to-see-my-notifications', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(716, 40, 'Tutor booking', 'tutor-booking', 1, 5, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(718, 156, 'Academy LMS Tutor booking addon', 'academy-lms-tutor-booking-addon', 0, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(719, 157, 'How to integrate your customization features after updating the application?', 'how-to-integrate-your-customization-features-after-updating-the-application', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(720, 157, 'What kind of license should I purchase?', 'what-kind-of-license-should-i-purchase', 1, 0, 10, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(721, 158, 'What is Ekushe project manager', 'what-is-ekushe-project-manager', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(722, 158, 'Basic terms', 'basic-terms', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(723, 159, 'How Ekushe project manager works', 'how-ekushe-project-manager-works', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(724, 159, 'How to install Ekushe project manager', 'how-to-install-ekushe-project-manager', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(725, 159, 'Website backend', 'website-backend', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(726, 159, 'Content safety', 'content-safety', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(727, 160, 'Managing client', 'managing-client', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(728, 160, 'Managing company', 'managing-company', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(729, 161, 'Managing Admin', 'managing-admin', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(730, 161, 'Managing Staff', 'managing-staff', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(731, 161, 'Permission', 'permission', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(732, 162, 'Adding new team task', 'adding-new-team-task', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(733, 162, 'Running task', 'running-task', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(734, 162, 'Archived task', 'archived-task', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(735, 163, 'Calendar', 'calendar', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(736, 163, 'Noticeboard', 'noticeboard', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(737, 163, 'Message', 'message', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(738, 163, 'Note', 'note', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(739, 163, 'Report', 'report', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(740, 164, 'How to complete a payment (Client)', 'how-to-complete-a-payment-client', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(741, 164, 'Client payment (Admin)', 'client-payment-admin', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(742, 164, 'Expense category', 'expense-category', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(743, 164, 'Managing expenses', 'managing-expenses', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(744, 165, 'Creating new ticket', 'creating-new-ticket', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(745, 165, 'Managing tickets', 'managing-tickets', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(746, 165, 'Macro', 'macro', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(747, 166, 'System settings', 'system-settings', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(748, 166, 'Email template', 'email-template', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(749, 166, 'SMTP settings', 'smtp-settings', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(750, 166, 'Payment settings', 'payment-settings', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(751, 166, 'Language settings ', 'language-settings', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(752, 166, 'About ', 'about', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(753, 167, 'How to integrate your customization features after updating the application', 'how-to-integrate-your-customization-features-after-updating-the-application', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(754, 167, 'What kind of license should I purchase?', 'what-kind-of-license-should-i-purchase', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(755, 131, 'Website settings', 'website-settings', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(756, 131, 'FAQ settings', 'faq-settings', 1, 0, 8, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(757, 34, 'Tax', 'tax', 1, 0, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(758, 38, 'Data center', 'data-center', 1, 9, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(759, 35, 'Private course', 'private-course', 1, 9, 1, '2023-02-15 06:26:30', '2023-02-15 06:26:30'),
(760, 167, 'How to update the application version', 'how-to-update-the-application-version', 1, 0, 11, '2023-02-15 06:26:30', '2023-02-15 06:26:30');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE `language` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `phrase` varchar(300) DEFAULT NULL,
  `translated` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`id`, `name`, `phrase`, `translated`) VALUES
(1, 'english', 'My Products', 'My Products'),
(2, 'english', 'Products', 'Products'),
(3, 'english', 'Product type', 'Product type'),
(4, 'english', 'Admin Panel', 'Admin Panel'),
(5, 'english', 'Create new type', 'Create new type'),
(6, 'english', 'Prev', 'Prev'),
(7, 'english', 'Next', 'Next'),
(8, 'english', 'Prevs', 'Prevs'),
(9, 'english', 'Create new product', 'Create new product'),
(10, 'english', 'Create product', 'Create product'),
(11, 'english', 'Close', 'Close'),
(12, 'english', 'Title', 'Title'),
(13, 'english', 'Identifier', 'Identifier'),
(14, 'english', 'Action', 'Action'),
(15, 'english', 'SCHOOL INFO', 'SCHOOL INFO'),
(16, 'english', 'School Name', 'School Name'),
(17, 'english', 'School Address', 'School Address'),
(18, 'english', 'School Email', 'School Email'),
(19, 'english', 'School Phone', 'School Phone'),
(20, 'english', 'Submit', 'Submit'),
(21, 'english', 'product_title', 'product_title'),
(22, 'english', 'product_name', 'product_name'),
(23, 'english', 'product_sub_title', 'product_sub_title'),
(24, 'english', 'product_type', 'product_type'),
(25, 'english', 'product_thumbnail', 'product_thumbnail'),
(26, 'english', 'favicon', 'favicon'),
(27, 'english', 'Product title', 'Product title'),
(28, 'english', 'Product name', 'Product name'),
(29, 'english', 'Product subtitle', 'Product subtitle'),
(30, 'english', 'Web Application', 'Web Application'),
(31, 'english', 'WordPress Plugin', 'WordPress Plugin'),
(32, 'english', 'WordPress Theme', 'WordPress Theme'),
(33, 'english', 'Product thumbnail', 'Product thumbnail'),
(34, 'english', 'FFavicon', 'FFavicon'),
(35, 'english', 'Delete', 'Delete'),
(36, 'english', 'Are you sure?', 'Are you sure?'),
(37, 'english', 'You won\'t able to revert this!', 'You won\'t able to revert this!'),
(38, 'english', 'Yes', 'Yes'),
(39, 'english', 'Cancel', 'Cancel'),
(40, 'english', 'Update product', 'Update product'),
(41, 'english', 'Edit', 'Edit'),
(42, 'english', 'Documentation', 'Documentation'),
(43, 'english', 'Go to documentation', 'Go to documentation'),
(44, 'english', 'Export Documentation', 'Export Documentation'),
(45, 'english', 'Topics and aricles of product : {{ $product->name }}', 'Topics and aricles of product : {{ $product->name }}'),
(46, 'english', 'Topics and aricles of product : Academy LMS', 'Topics and aricles of product : Academy LMS'),
(47, 'english', 'Topics and aricles of product : Locus', 'Topics and aricles of product : Locus'),
(48, 'english', 'Add new topic', 'Add new topic'),
(49, 'english', 'Add new article', 'Add new article'),
(50, 'english', 'Sort topics', 'Sort topics'),
(51, 'english', 'Back to products', 'Back to products'),
(52, 'english', 'Topics and aricles of product : Mastery LMS', 'Topics and aricles of product : Mastery LMS'),
(53, 'english', 'Topics', 'Topics'),
(54, 'english', 'Articles', 'Articles'),
(55, 'english', 'Sort', 'Sort'),
(56, 'english', 'Sort Docs', 'Sort Docs'),
(57, 'english', 'Sort Product', 'Sort Product'),
(58, 'english', 'Create new topic', 'Create new topic'),
(59, 'english', 'Your title', 'Your title'),
(60, 'english', 'Topic thumbnail', 'Topic thumbnail'),
(61, 'english', 'The image size should be', 'The image size should be'),
(62, 'english', 'Topic', 'Topic'),
(63, 'english', 'Summary', 'Summary'),
(64, 'english', 'Make this topic public', 'Make this topic public');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `product_type_id` bigint(20) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `directory` varchar(255) DEFAULT NULL,
  `favicon` varchar(255) DEFAULT 'placeholder.png',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `product_type_id`, `order`, `thumbnail`, `slug`, `sub_title`, `directory`, `favicon`, `created_at`, `updated_at`) VALUES
(1, 'Academy LMS', 1, NULL, '586f7fa8dae6de733dbd244389b78a0b.jpg', 'academy-lms', 'Learning Management System', '3Fq20DKUZ8rTwSnsWOcMPai7tXbu4R', 'ab8ae88cbacc378342fd75155d2cc38f.png', '2023-02-13 09:14:54', '2023-02-13 09:14:54'),
(2, 'Ekattor 7', 1, NULL, '48a3166d913b3b51d0533042bab996ab.jpg', 'ekattor-7', 'School Management System', 'WmdTCnLxaNbwD4Zgk2zlJyV6IOjBEu', 'cc22eb4dcea316bc82cd727f51eb3951.png', '2023-02-13 09:14:54', '2023-02-13 09:14:54'),
(3, 'Learny LMS', 2, NULL, 'f062b21ccbd7656eb2498291aff33164.jpg', 'learny-lms', 'Coming Soon...', '1zNmcF0PqAZJB5VY3kn7ltfEXj4gHK', 'bb9027876e4dde08bfe682da89469319.png', '2023-02-13 09:14:54', '2023-02-13 09:14:54'),
(4, 'Mastery LMS', 1, NULL, '18c869ef4f270f0c35ca5d429e71f1f0.jpg', 'mastery-lms', 'Subscription Based LMS', 'eCrby2vFplc8igAB0uY1UmIjNQqHxt', '4a6cd79c1533906b0e644100aa1f5e0c.png', '2023-02-13 09:14:54', '2023-02-13 09:14:54'),
(5, 'Checkout', 1, NULL, '9172b16b871e62e20b29271b7cf95186.jpg', 'checkout', 'Online Grocery Store', 'pevB9q4LUPW1kGj', 'a5123ba879abc59598bc99e55a9f5656.png', '2023-02-13 09:14:54', '2023-02-13 09:14:54'),
(6, 'Atlas', 1, NULL, '35a3b8b31c201e8026e9d92035271d19.jpg', 'atlas', 'business directory listing', 'KCJBzeQR72qhIlu', '3bd39669a32f77db0112a8942fb38ff9.png', '2023-02-13 09:14:54', '2023-02-13 09:14:54'),
(8, 'Ekattor 8', 1, NULL, '68e7efff55d5aa533aa72387abebf309.jpg', 'ekattor-8', 'School management system', 'eTbJgzBlkErQ0so', 'c8a90f8900e968f4cf7edef62de6a239.png', '2023-02-13 09:14:54', '2023-02-13 09:14:54'),
(10, 'Sociopro', 1, NULL, '6b5899ad810041d4df669a2e691f6ee6.jpg', 'sociopro', 'Private social platform', '6I1jkDlqH7X2Gxi', 'bcb6c42489772bf2db807695dd3baae8.png', '2023-02-13 09:14:54', '2023-02-13 09:14:54'),
(11, 'Ekushe CRM', 1, NULL, '131364c3e3537738623594d53e5958ea.jpg', 'ekushe-crm', 'Project management system', 'p47juD1biEXoRVY', '60cf10b8d7514abbad8a0edb62568c3e.png', '2023-02-13 09:14:54', '2023-02-13 09:14:54'),
(14, 'Locus', 1, NULL, 'YuvQ2mWX07CTRgq.png', 'locus', 'Business directory Listing', NULL, 'GDgvImKhe8WOUHo.png', '2023-02-14 09:59:55', '2023-02-14 10:50:08');

-- --------------------------------------------------------

--
-- Table structure for table `product_types`
--

CREATE TABLE `product_types` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_types`
--

INSERT INTO `product_types` (`id`, `name`, `identifier`, `created_at`, `updated_at`) VALUES
(1, 'Web Application', 'web-app', '2023-02-13 09:09:15', '2023-02-13 09:09:15'),
(2, 'WordPress Plugin', 'wp-plugin', '2023-02-13 09:09:34', '2023-02-13 09:09:34'),
(3, 'WordPress Theme', 'wp-theme', '2023-02-13 09:09:54', '2023-02-13 09:09:54');

-- --------------------------------------------------------

--
-- Table structure for table `roles_and_permissions`
--

CREATE TABLE `roles_and_permissions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `projects` int(11) DEFAULT 0,
  `products` int(11) DEFAULT 0,
  `blog` int(11) DEFAULT 0,
  `doc` int(11) DEFAULT 0,
  `user` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `roles_and_permissions`
--

INSERT INTO `roles_and_permissions` (`id`, `name`, `slug`, `projects`, `products`, `blog`, `doc`, `user`, `created_at`, `updated_at`) VALUES
(1, 'Superadmin', 'superadmin', 1, 1, 1, 1, 1, '2023-02-14 05:14:35', '2023-02-14 05:14:35'),
(2, 'Project Admin', 'project_admin', 1, 0, 0, 0, 0, '2023-02-14 05:15:36', '2023-02-14 05:15:36'),
(3, 'Blog Writer', 'blog_writer', 0, 0, 1, 0, 0, '2023-02-14 05:16:02', '2023-02-14 05:16:02'),
(4, 'Document Writer', 'doc_writer', 0, 0, 0, 1, 0, '2023-02-14 05:16:53', '2023-02-14 05:16:53');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`) VALUES
(1, 'system_name', 'Creativeitem'),
(2, 'system_title', 'Creativeitem'),
(4, 'language', 'english'),
(5, 'recaptcha_sitekey', '6Lep_30bAAAAALDw_yKr-3KgRAROTneAwmGnweOB'),
(6, 'recaptcha_secretkey', '6Lep_30bAAAAAAR287vN6wSjmDrhZb6lB_4eIlkh'),
(7, 'timezone', 'Asia/Dhaka'),
(8, 'system_currency', 'USD'),
(9, 'paypal_currency', 'USD'),
(10, 'stripe_currency', 'USD'),
(11, 'currency_position', 'left'),
(12, 'paypal_keys', '[{\"active\":\"1\",\"mode\":\"sandbox\",\"sandbox_client_id\":\"ASM-7SWevW4YdWWJ1br3_QRfkIUmM05wHXe0jpV_DH1hy6ABaoYyUiUzQoOTK3i3IaUQXQHPiawyfCCB\",\"sandbox_secret_key\":\"EMzGO4heVFw1PEZ2LY6n37b_oDQa18AK2-rLrBEGojCOuEy938eqoSlcf4v-Q0xCX5xkFr0Gw_zelHSQ\",\"production_client_id\":\"1234\",\"production_secret_key\":\"1234\"}]'),
(13, 'stripe_keys', '[{\"active\":\"1\",\"testmode\":\"on\",\"public_key\":\"pk_test_CAC3cB1mhgkJqXtypYBTGb4f\",\"secret_key\":\"sk_test_iatnshcHhQVRXdygXw3L2Pp2\",\"public_live_key\":\"pk_live_xxxxxxxxxxxxxxxxxxxxxxxx\",\"secret_live_key\":\"sk_live_xxxxxxxxxxxxxxxxxxxxxxxx\"}]'),
(14, 'address', 'Florida, USA'),
(15, 'system_email', 'ceo@creativeitem.com'),
(16, 'campaign_bar', '<p></p>'),
(17, 'ad_activity_on_frontend', '1');

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `id` bigint(20) NOT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `summary` longtext DEFAULT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `visibility` int(11) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`id`, `topic`, `slug`, `product_id`, `summary`, `thumbnail`, `visibility`, `order`, `created_at`, `updated_at`) VALUES
(3, 'Introduction', 'introduction', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(5, 'Basics', 'basics', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(6, 'Getting Started ', 'getting-started', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(7, 'Managing users', 'managing-users', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(8, 'Academic activities', 'academic-activities', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(9, 'Exam management', 'exam-management', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(10, 'Accounting', 'accounting', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(11, 'School’s back office', 'school-s-back-office', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(13, 'Ekattor settings', 'ekattor-settings', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(14, 'Parent’s Panel', 'parent-s-panel', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(15, 'Addons', 'addons', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(16, 'Video tutorials ', 'video-tutorials', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(17, 'FAQ', 'faq', 2, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(28, 'Introduction', 'introduction', 4, '', 'topic-thumbnail.png', 1, 1, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(29, 'Getting Started With Mastery LMS', 'getting-started-with-mastery-lms', 4, '', 'topic-thumbnail.png', 1, 2, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(31, 'Introduction', 'introduction', 1, '', 'topic-thumbnail.png', 1, 1, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(34, 'Getting started', 'getting-started', 1, '', 'topic-thumbnail.png', 1, 2, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(35, 'Course management', 'course-management', 1, '', 'topic-thumbnail.png', 1, 3, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(36, 'Student’s learning process', 'student-s-learning-process', 1, '', 'topic-thumbnail.png', 1, 4, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(37, 'Earning from course selling', 'earning-from-course-selling', 1, '', 'topic-thumbnail.png', 1, 5, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(38, 'Administrative controls', 'administrative-controls', 1, '', 'topic-thumbnail.png', 1, 6, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(39, 'Instructor Flutter App', 'instructor-flutter-app', 1, '', 'topic-thumbnail.png', 1, 8, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(40, 'Installable addons', 'installable-addons', 1, '', 'topic-thumbnail.png', 1, 10, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(41, 'Installable themes', 'installable-themes', 1, '', 'topic-thumbnail.png', 1, 11, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(42, 'Video tutorial', 'video-tutorial', 1, '', 'topic-thumbnail.png', 1, 12, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(43, 'FAQ', 'faq', 1, '', 'topic-thumbnail.png', 1, 15, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(45, 'Setting Up The Class', 'setting-up-the-class', 4, '', 'topic-thumbnail.png', 1, 3, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(46, 'Student Usage Guide', 'student-usage-guide', 4, '', 'topic-thumbnail.png', 1, 7, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(47, 'Mastery Mobile Application', 'mastery-mobile-application', 4, '', 'topic-thumbnail.png', 1, 9, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(48, 'Mastery Settings', 'mastery-settings', 4, '', 'topic-thumbnail.png', 1, 4, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(49, 'Teacher Usage Guide', 'teacher-usage-guide', 4, '', 'topic-thumbnail.png', 1, 6, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(51, 'Getting Started with Mastery App Flutter', 'getting-started-with-mastery-app-flutter', 4, '', 'topic-thumbnail.png', 0, 8, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(61, 'Earning from course selling', 'earning-from-course-selling', 3, '', 'topic-thumbnail.png', 1, 5, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(63, 'Installable plugins', 'installable-plugins', 3, '', 'topic-thumbnail.png', 0, 8, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(65, 'FAQ', 'faq', 3, '', 'topic-thumbnail.png', 1, 13, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(66, 'Revenue Sharing', 'revenue-sharing', 4, '', 'topic-thumbnail.png', 1, 5, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(67, 'Student Flutter App', 'student-flutter-app', 1, '', 'topic-thumbnail.png', 1, 9, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(68, 'Introduction', 'introduction', 5, '', 'topic-thumbnail.png', 1, 1, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(70, 'Getting Started', 'getting-started', 5, '', 'topic-thumbnail.png', 1, 2, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(71, 'Product Management', 'product-management', 5, '', 'topic-thumbnail.png', 1, 4, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(72, 'Category Management', 'category-management', 5, '', 'topic-thumbnail.png', 1, 5, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(73, 'Users', 'users', 5, '', 'topic-thumbnail.png', 1, 6, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(75, 'Settings', 'settings', 5, '', 'topic-thumbnail.png', 1, 7, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(76, 'Profile', 'profile', 5, '', 'topic-thumbnail.png', 1, 8, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(77, 'Checkout Customer Mobile App', 'checkout-customer-mobile-app', 5, '', 'topic-thumbnail.png', 1, 9, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(81, 'Order Management', 'order-management', 5, '', 'topic-thumbnail.png', 1, 3, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(86, 'Checkout Delivery Boy Mobile App', 'checkout-delivery-boy-mobile-app', 5, '', 'topic-thumbnail.png', 1, 10, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(87, 'What is Learny LMS', 'what-is-learny-lms', 3, '', 'topic-thumbnail.png', 1, 1, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(88, 'Getting started with Learny ', 'getting-started-with-learny', 3, '', 'topic-thumbnail.png', 1, 2, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(89, 'Managing users', 'managing-users', 3, '', 'topic-thumbnail.png', 1, 3, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(90, 'Course management', 'course-management', 3, '', 'topic-thumbnail.png', 1, 4, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(91, 'WooCommerce integration', 'woocommerce-integration', 3, '', 'topic-thumbnail.png', 1, 6, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(92, 'Elementor integration', 'elementor-integration', 3, '', 'topic-thumbnail.png', 1, 7, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(93, 'Instructor account activities', 'instructor-account-activities', 3, '', 'topic-thumbnail.png', 1, 9, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(94, 'Student account activities', 'student-account-activities', 3, '', 'topic-thumbnail.png', 1, 10, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(95, 'Live Class', 'live-class', 3, '', 'topic-thumbnail.png', 1, 11, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(96, 'Introduction', 'introduction', 6, '', 'topic-thumbnail.png', 1, 1, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(97, 'Getting Started', 'getting-started', 6, '', 'topic-thumbnail.png', 1, 2, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(98, 'Listing Management', 'listing-management', 6, '', 'topic-thumbnail.png', 1, 3, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(99, 'Configuring Atlas', 'configuring-atlas', 6, '', 'topic-thumbnail.png', 1, 4, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(100, 'Earning from Atlas', 'earning-from-atlas', 6, '', 'topic-thumbnail.png', 1, 5, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(101, 'Customers account', 'customers-account', 6, '', 'topic-thumbnail.png', 1, 6, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(102, 'Installable addons', 'installable-addons', 6, '', 'topic-thumbnail.png', 1, 7, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(104, 'FAQ', 'faq', 6, '', 'topic-thumbnail.png', 1, 9, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(105, 'Certificate', 'certificate', 3, '', 'topic-thumbnail.png', 1, 12, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(106, 'Academy LMS Affiliate addon', 'academy-lms-affiliate-addon', 1, '', 'topic-thumbnail.png', 1, 13, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(107, 'FAQ', 'faq', 4, '', 'topic-thumbnail.png', 1, 10, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(108, 'FAQ', 'faq', 5, '', 'topic-thumbnail.png', 1, 11, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(109, 'Blogs', 'blogs', 1, '', 'topic-thumbnail.png', 1, 7, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(110, 'Video Subscription Service', 'video-subscription-service', 1, '', 'topic-thumbnail.png', 1, 14, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(123, 'Introduction', 'introduction', 8, '', 'topic-thumbnail.png', 1, 2, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(124, 'Basics', 'basics', 8, '', 'topic-thumbnail.png', 1, 3, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(125, 'Getting Started', 'getting-started', 8, '', 'topic-thumbnail.png', 1, 4, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(126, 'Managing users', 'managing-users', 8, '', 'topic-thumbnail.png', 1, 5, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(127, 'Academic activities', 'academic-activities', 8, '', 'topic-thumbnail.png', 1, 6, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(128, 'Exam management', 'exam-management', 8, '', 'topic-thumbnail.png', 1, 7, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(129, 'Accounting', 'accounting', 8, '', 'topic-thumbnail.png', 1, 8, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(130, 'Back office', 'back-office', 8, '', 'topic-thumbnail.png', 1, 9, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(131, 'Settings', 'settings', 8, '', 'topic-thumbnail.png', 1, 10, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(132, 'Parent’s panel', 'parent-s-panel', 8, '', 'topic-thumbnail.png', 1, 11, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(133, 'Addon bundle', 'addon-bundle', 8, '', 'topic-thumbnail.png', 1, 12, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(134, 'FAQ', 'faq', 8, '', 'topic-thumbnail.png', 1, 13, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(140, 'Introduction', 'introduction', 10, '', 'topic-thumbnail.png', 1, 1, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(141, 'Getting Started', 'getting-started', 10, '', 'topic-thumbnail.png', 1, 2, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(142, 'Login credentials', 'login-credentials', 10, '', 'topic-thumbnail.png', 1, 3, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(143, 'Sociopro Timeline', 'sociopro-timeline', 10, '', 'topic-thumbnail.png', 1, 4, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(144, 'Sociopro Profile', 'sociopro-profile', 10, '', 'topic-thumbnail.png', 1, 5, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(145, 'Sociopro Group', 'sociopro-group', 10, '', 'topic-thumbnail.png', 1, 6, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(146, 'Sociopro Page', 'sociopro-page', 10, '', 'topic-thumbnail.png', 1, 7, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(147, 'Sociopro blogs', 'sociopro-blogs', 10, '', 'topic-thumbnail.png', 1, 8, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(148, 'Sociopro Event', 'sociopro-event', 10, '', 'topic-thumbnail.png', 1, 9, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(149, 'Sociopro videos and shorts', 'sociopro-videos-and-shorts', 10, '', 'topic-thumbnail.png', 1, 10, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(150, 'Sociopro Marketplace', 'sociopro-marketplace', 10, '', 'topic-thumbnail.png', 1, 11, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(151, 'Sociopro story', 'sociopro-story', 10, '', 'topic-thumbnail.png', 1, 12, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(152, 'Admin panel', 'admin-panel', 10, '', 'topic-thumbnail.png', 1, 14, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(153, 'Settings', 'settings', 10, '', 'topic-thumbnail.png', 1, 15, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(154, 'Messaging & Notifications', 'messaging-notifications', 10, '', 'topic-thumbnail.png', 1, 13, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(156, 'Creativeitem', 'creativeitem', 1, '', 'topic-thumbnail.png', 1, 16, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(157, 'FAQ', 'faq', 10, '', 'topic-thumbnail.png', 1, 16, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(158, 'Introduction', 'introduction', 11, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(159, 'Getting Started', 'getting-started', 11, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(160, 'Managing customers', 'managing-customers', 11, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(161, 'Managing team', 'managing-team', 11, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(162, 'Team task', 'team-task', 11, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(163, 'Managing other activities', 'managing-other-activities', 11, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(164, 'Accounting', 'accounting', 11, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(165, 'Client support', 'client-support', 11, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(166, 'Settings', 'settings', 11, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44'),
(167, 'FAQ', 'faq', 11, '', 'topic-thumbnail.png', 1, 0, '2023-02-15 06:23:44', '2023-02-15 06:23:44');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `about` longtext DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role_id`, `status`, `thumbnail`, `phone`, `designation`, `about`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'John Doe', 'superadmin@example.com', NULL, '$2y$10$uJzKhDUlTkoHwsUcGBxRJ.nmHdv0Q5t4oKVV158lS.SuduVPlti/q', 1, NULL, NULL, NULL, NULL, NULL, NULL, '2023-02-12 02:06:09', '2023-02-12 02:06:09'),
(2, 'Jacob Jones', 'customer@example.com', NULL, '$2y$10$kyUydXTV4457kWjC3lFPRePf3VHerIdZL5DsP4An6txX.coH4i2ha', 2, NULL, NULL, NULL, NULL, NULL, NULL, '2023-02-12 06:00:14', '2023-02-12 06:00:14'),
(3, 'Ban Ki Moon', 'bkmoon@example.com', NULL, '$2y$10$XUdEmVwKXymC6PQnzUFoN.sJRr7wh864cFuA1hfX/uTiFZDNQI0Mi', 2, NULL, NULL, NULL, NULL, NULL, NULL, '2023-02-12 06:02:21', '2023-02-12 06:02:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ad_dimentions`
--
ALTER TABLE `ad_dimentions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `articles_topic_id_foreign` (`topic_id`),
  ADD KEY `articles_product_id_foreign` (`product_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `language`
--
ALTER TABLE `language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_product_type_id_foreign` (`product_type_id`);

--
-- Indexes for table `product_types`
--
ALTER TABLE `product_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles_and_permissions`
--
ALTER TABLE `roles_and_permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `topics_product_id_foreign` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ad_dimentions`
--
ALTER TABLE `ad_dimentions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=761;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `language`
--
ALTER TABLE `language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `product_types`
--
ALTER TABLE `product_types`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roles_and_permissions`
--
ALTER TABLE `roles_and_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=168;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `articles_topic_id_foreign` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_product_type_id_foreign` FOREIGN KEY (`product_type_id`) REFERENCES `product_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `topics`
--
ALTER TABLE `topics`
  ADD CONSTRAINT `topics_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
