<script setup>
</script>

<template>
    <!-- Start Breadcrumb -->
    <section class="breadcrumb-section">
      <div class="breadcrumb-one-graphic-1">
        <img :src=" $page.props.base.url + '/public/assets/img/banner-graphic-1.png'" alt="" />
      </div>
      <div class="breadcrumb-one-graphic-2">
        <img :src=" $page.props.base.url + '/public/assets/img/banner-graphic-2.png'" alt="" />
      </div>
    </section>
    <!-- End Breadcrumb -->
</template>